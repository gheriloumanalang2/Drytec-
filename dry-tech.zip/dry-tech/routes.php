<?php

return [
    'home'      => __DIR__ . '/pages/home/index.php',
    'login'     => __DIR__ . '/pages/login/index.php',
    'logout'    => __DIR__ . '/pages/logout/index.php',
    'register'  => __DIR__ . '/pages/register/index.php',
    'dashboard' => __DIR__ . '/pages/admin/index.php',
    'projects'         => __DIR__ . '/pages/admin/projects/index.php',
    'projects/create'  => __DIR__ . '/pages/admin/projects/create.php',
    'projects/show'    => __DIR__ . '/pages/admin/projects/show.php',
    'inquiries' => __DIR__ . '/pages/admin/inquiries/index.php',
    'users' => __DIR__ . '/pages/admin/users/index.php',
    'feedback' => __DIR__ . '/pages/admin/feedback/index.php',
    'profile' => __DIR__ . '/pages/admin/profile/index.php',
    'chat-list' => __DIR__ . '/pages/admin/chat-list/index.php',
    'conversations' =>  __DIR__ . '/pages/admin/chat-list/conversations.php',
    'all-reviews' => __DIR__ . '/pages/all-reviews/index.php',
    'reset-password' => __DIR__ . '/pages/password/index.php',
    'password/reset' => __DIR__ . '/pages/password/reset.php',
    'chat' => __DIR__ . '/pages/chat/index.php',
    'verify' => __DIR__ . '/pages/verify/index.php'
];

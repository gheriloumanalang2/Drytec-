<?php
require_once '../classes/Db.php';

$conversation_id = isset($_GET['conversation_id']) ? (int) $_GET['conversation_id'] : 0;
$current_user_id = $_SESSION['user_id'] ?? 0;

if (empty($conversation_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid conversation ID']);
    exit;
}

try {
    // $update = "UPDATE messages 
    //            SET is_read = 1 
    //            WHERE conversation_id = ? ";
    // $stmtUpdate = $conn->prepare($update);
    // $stmtUpdate->execute([$conversation_id]);

    $query = "SELECT *
              FROM messages m
              JOIN users u ON m.sender_id = u.id
              WHERE m.conversation_id = ?
              ORDER BY m.created_at ASC";

    $stmt = $conn->prepare($query);
    $stmt->execute([$conversation_id]);

    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['status' => 'success', 'messages' => $messages]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to fetch messages: ' . $e->getMessage()]);
}

<?php

require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $feedbackId = $_POST['feedback_id'];

    $stmt = $conn->prepare("UPDATE ratings SET status = 'Disapprove' WHERE id = :id");
    $stmt->bindParam(':id', $feedbackId);
    $stmt->execute();

    header("Location: ../feedback");
}

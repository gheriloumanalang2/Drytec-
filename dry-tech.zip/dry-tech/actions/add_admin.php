<?php

require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    $hashed = password_hash($password, PASSWORD_BCRYPT);
    try {
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, role, is_verified, is_active) VALUES (?, ?, ?, 'Admin', 1, 1)");
        $stmt->execute([$name, $email, $hashed]);
        header('Location: ' . $_SERVER['HTTP_REFERER']);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}

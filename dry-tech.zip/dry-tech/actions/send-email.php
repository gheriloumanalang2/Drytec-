<?php

use Dotenv\Dotenv;

session_start();

require_once  __DIR__ . '/../vendor/autoload.php';
require_once  __DIR__ . '/../classes/Db.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

use App\Class\Mailer;

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $email = $_POST['email'];

    $stmt = $conn->prepare("SELECT COUNT(*) AS exists_email FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && $user['exists_email'] > 0) {
        $token = bin2hex(random_bytes(32));
        $expires = date("Y-m-d H:i:s", strtotime("+3 minutes"));

        $stmt = $conn->prepare("REPLACE INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$email, $token, $expires]);

        $resetLink = $_ENV['APP_URL'] . "/password/reset?token=$token";

        $subject = "Password Reset Link Request";

        $message  = "Hello, <br><br>";
        $message .= "We received a request to reset your password. <br>";
        $message .= "Click the link below to reset it (valid for 3 minutes):<br>";
        $message .= "<a href='" . $resetLink . "'>" . $resetLink . "</a><br><br>";
        $message .= "If you didn’t request a password reset, please ignore this email.<br><br>";
        $message .= "Regards,<br>Dry-Tech Team";

        $mail = Mailer::send($email, $subject, $message);


        $_SESSION['success'] = "Reset link has been sent to your email.";
        header("Location: ../reset-password");
        exit();
    } else {
        $_SESSION['error'] = "Email not found.";
        header("Location: ../reset-password");
        exit();
    }
}

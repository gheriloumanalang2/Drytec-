<?php

session_start();

require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);

    $errors = [];

    if (empty($email)) {
        $errors['email'] = 'Email is required.';
    }

    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    }

    if (!empty($errors)) {
        echo json_encode([
            'success' => false,
            'errors' => $errors
        ]);
        exit;
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        if ($user['is_verified'] != 1) {
            echo json_encode([
                'success' => false,
                'errors' => [
                    'email' => 'Your account is not yet verified.'
                ]
            ]);
            exit;
        }

        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['name'] = $user['name'];

        echo json_encode([
            'success' => true
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'errors' => [
                'email' => 'Invalid email or password',
            ]
        ]);
    }
}

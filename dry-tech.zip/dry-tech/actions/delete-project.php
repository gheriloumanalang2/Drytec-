<?php

require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $project_id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM projects WHERE id = :id");
    $stmt->bindParam(':id', $project_id);
    $stmt->execute();

    echo json_encode(['success' => true, 'message' => 'Project deleted']);
}

<?php
require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['projectId'])) {
    $projectId = $_POST['projectId'];
    $title = $_POST['title'];
    $contract_package = $_POST['contract_package'];

    $stmt = $conn->prepare("UPDATE projects SET title = ?, contract_package = ?, is_planning = 0, status = 'On-Going' WHERE id = ?");
    $stmt->execute([$title, $contract_package, $projectId]);

    header("Location:../projects");
    exit;
}

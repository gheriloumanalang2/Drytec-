<?php
require_once '../classes/Db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['action'], $_POST['id'])) {
    $id = $_POST['id'];
    $action = $_POST['action'];

    $conn->beginTransaction();

    try {
        if ($action === "inquiry") {
            $deleteProjectsStmt = $conn->prepare("DELETE FROM projects WHERE contact_id = ?");
            $deleteProjectsSuccess = $deleteProjectsStmt->execute([$id]);

            $deleteContactStmt = $conn->prepare("DELETE FROM contact_messages WHERE id = ?");
            $deleteContactSuccess = $deleteContactStmt->execute([$id]);

            if ($deleteProjectsSuccess && $deleteContactSuccess) {
                $conn->commit();
                echo json_encode(['success' => true]);
            } else {
                $conn->rollBack();
                echo json_encode(['success' => false, 'error' => 'Failed to delete related projects or contact message']);
            }
        } else {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $success = $stmt->execute([$id]);

            if ($success) {
                $conn->commit();
                echo json_encode(['success' => true]);
            } else {
                $conn->rollBack();
                echo json_encode(['success' => false, 'error' => 'Failed to delete user']);
            }
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}

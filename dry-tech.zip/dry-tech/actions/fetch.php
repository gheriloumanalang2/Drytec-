<?php
session_start();

require_once '../classes/Db.php';


if (isset($_GET)) {
    $currentUserId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

    $stmt = $conn->prepare("SELECT id AS conversation_id 
                       FROM conversations
                       WHERE user_id = :user_id
                       LIMIT 1");
    $stmt->bindParam(':user_id', $currentUserId, PDO::PARAM_INT);
    $stmt->execute();
    $conversation = $stmt->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['conversation_id' => $conversation['conversation_id']]);
}

<?php

require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $feedbackId = $_POST['contactid'];

    $stmt = $conn->prepare("UPDATE projects SET status = 'Planning', is_planning = 1 WHERE contact_id = :id");
    $stmt->bindParam(':id', $feedbackId);
    $stmt->execute();

    header("Location: ../inquiries");
}

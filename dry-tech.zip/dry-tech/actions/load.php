<?php

session_start();

require_once '../classes/Db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $currentId = $_SESSION['user_id'];

    $unread = $conn->prepare("SELECT COUNT(*) AS unread_count FROM messages WHERE is_read = 0 AND sender_id != ? ");
    $unread->execute([$currentId]);
    $data = $unread->fetch(PDO::FETCH_ASSOC);

    echo json_encode(['count' => $data['unread_count']]);
}

<?php

use App\Class\Session;
use Dotenv\Dotenv;

session_start();

require_once  __DIR__ . '/../vendor/autoload.php';
require_once  __DIR__ . '/../classes/Db.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();


if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);

    $stmt = $conn->prepare("SELECT * FROM password_resets WHERE token = ?");
    $stmt->execute([$token]);
    $reset = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$reset) {
        Session::set('error', "Invalid or expired token.");
        header("location: ../password/reset?token=" . $token);
        exit();
    }

    $now = new DateTime();
    $expires = new DateTime($reset['expires_at']);

    if ($now > $expires) {
        Session::set('error', "Token has expired.");
        header("location: ../password/reset?token=" . $token);
        exit();
    }

    if ($new_password != $password_confirmation) {
        Session::set('error', "New Password does not match to Confirm Password");
        header("location: ../password/reset?token=" . $token);
        exit();
    }


    $newHash = password_hash($new_password, PASSWORD_BCRYPT);


    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? ");
    $stmt->execute([$reset['email']]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ? ");
    $stmt->execute([$newHash, $user['id']]);
    if ($stmt) {
        $stmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
        $stmt->execute([$token]);

        Session::set('success', "New Password has been set, please login.");
        header("location: ../login");
        exit();
    }
}

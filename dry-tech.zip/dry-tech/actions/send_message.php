<?php

use Dotenv\Dotenv;

session_start();

$currentUser = $_SESSION['user_id'];

require_once '../classes/Db.php';
require_once '../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../'); // actions /\\.env - dry-tect/.env
$dotenv->load();

$conversation_id = isset($_POST['conversation_id']) ? (int) $_POST['conversation_id'] : 0;
$sender_id = isset($_POST['sender_id']) ? (int) $_POST['sender_id'] : 0;
$message = isset($_POST['message']) ? trim(htmlspecialchars($_POST['message'])) : '';

// Allow empty messages if there's an attachment
$hasAttachment = isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK;

if (empty($message) && !$hasAttachment) {
    echo json_encode(['status' => 'error', 'message' => 'Message or attachment required.']);
    exit;
}

try {
    // If no conversation_id is passed, create a new conversation
    if ($conversation_id === 0) {
        // Check if user already has a conversation
        $stmt = $conn->prepare("SELECT id FROM conversations WHERE user_id = ?");
        $stmt->execute([$currentUser]);
        $existingConversation = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingConversation) {
            $conversation_id = $existingConversation['id'];
        } else {
            // Create new conversation
            $stmt = $conn->prepare("INSERT INTO conversations (user_id) VALUES (?)");
            $stmt->execute([$currentUser]);
            $conversation_id = $conn->lastInsertId();

            // Add user to conversation_user table
            $stmt = $conn->prepare("INSERT INTO conversation_user (conversation_id, user_id) VALUES (?, ?)");
            $stmt->execute([$conversation_id, $currentUser]);
        }
    }

    // Handle file upload if present
    $attachment_path = null;
    $attachment_name = null;

    if ($hasAttachment) {
        // Create upload directory if it doesn't exist
        $upload_dir = '../assets/uploads/attachments/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        // Generate a unique filename
        $file_extension = pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION);
        $unique_filename = uniqid('attachment_') . '.' . $file_extension;
        $attachment_path = 'uploads/attachments/' . $unique_filename;
        $full_path = $upload_dir . $unique_filename;
        $attachment_name = $_FILES['attachment']['name'];

        // Move the uploaded file
        if (!move_uploaded_file($_FILES['attachment']['tmp_name'], $full_path)) {
            echo json_encode(['status' => 'error', 'message' => 'Failed to upload attachment.']);
            exit;
        }
    }

    if ($attachment_path) {
        $stmt = $conn->prepare("INSERT INTO messages (conversation_id, sender_id, message, attachment_path, attachment_name) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$conversation_id, $sender_id, $message, $attachment_path, $attachment_name]);
    } else {
        $stmt = $conn->prepare("INSERT INTO messages (conversation_id, sender_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$conversation_id, $sender_id, $message]);
    }

    $message_id = $conn->lastInsertId();

    // Get sender name
    $stmt = $conn->prepare("SELECT name FROM users WHERE id = ?");
    $stmt->execute([$sender_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $sender_name = $user ? $user['name'] : 'Unknown';

    $data = [
        'message_id' => $message_id,
        'conversation_id' => $conversation_id,
        'sender_id' => $sender_id,
        'message' => $message,
        'sender_name' => $sender_name
    ];

    // Add attachment URL if present
    if ($attachment_path) {
        $base_url = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $base_url .= "://" . $_SERVER['HTTP_HOST'];
        $base_url .= dirname(dirname($_SERVER['PHP_SELF'])) . '/';

        $data['attachment_url'] = $base_url . $attachment_path;
        $data['attachment_name'] = $attachment_name;
    }

    // Send real-time update via Pusher
    $pusher = new Pusher\Pusher(
        $_ENV['PUSHER_APP_KEY'],
        $_ENV['PUSHER_APP_SECRET'],
        $_ENV['PUSHER_APP_ID'],
        ['cluster' => $_ENV['PUSHER_APP_CLUSTER']]
    );

    $pusher->trigger('conversation.' . $conversation_id, 'message.sent', $data);

    echo json_encode([
        'status' => 'success',
        'message' => 'Message sent successfully',
        'data' => $data
    ]);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Failed to send message: ' . $e->getMessage()]);
}

<?php

require_once '../classes/Db.php';

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);

    $stmt = $conn->prepare("INSERT INTO ratings (`name`, `email`, `rating`, `comments`)VALUES(?,?,?,?) ");
    $stmt->execute([$name, $email, $rating, $comments]);
    if ($stmt) {
        echo json_encode([
            "success" => true,
            'message' => "Inquiries successfully submitted"
        ]);
    }
}

<?php

use App\Class\Mailer;
use Dotenv\Dotenv;

session_start();
require_once  '../vendor/autoload.php';
require_once '../classes/Db.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    extract($_POST);
    $errors = [];

    if (empty($firstName)) {
        $errors['firstName'] = 'Firstname is required.';
    }

    if (empty($middleName)) {
        $errors['middleName'] = 'Middlename is required.';
    }

    if (empty($lastName)) {
        $errors['lastName'] = 'Lastname is required.';
    }

    if (empty($email)) {
        $errors['email'] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format.';
    } else {
        // Extract domain part from email
        $domain = substr(strrchr($email, "@"), 1);
        // Check if the domain has MX records (Mail Exchange) or A records (Address)
        if (!checkdnsrr($domain, "MX") && !checkdnsrr($domain, "A")) {
            $errors['email'] = 'The domain does not exist or is not reachable for email.';
        }
    }


    if (empty($password)) {
        $errors['password'] = 'Password is required.';
    }

    if ($password !== $password_confirmation) {
        $errors['password_confirmation'] = 'Password confirmation does not match.';
    }

    if (!empty($errors)) {
        echo json_encode([
            'success' => false,
            'errors' => $errors
        ]);
        exit;
    }

    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $exists = $stmt->fetchColumn();

    if ($exists > 0) {
        echo json_encode([
            'success' => false,
            'errors' => [
                'email' => 'Email already exists.'
            ]
        ]);
        exit;
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $verify_token = bin2hex(random_bytes(16));

    $fullName = $firstName . " " . $middleName . " " . $lastName;

    $stmt = $conn->prepare("INSERT INTO users (name, middleName, lastName, email, password, verify_token) VALUES (:name, :middleName, :lastName, :email, :password, :token)");
    $stmt->bindParam(':name', $firstName);
    $stmt->bindParam(':middleName', $middleName);
    $stmt->bindParam(':lastName', $lastName);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':token', $verify_token);
    if ($stmt->execute()) {
        $verifyUrl = $_ENV['APP_URL']  . "/verify?token=" . $verify_token;

        $subject = "Account Verification Link";

        $message = "Hi " . $fullName . ",<br><br>";
        $message .= "Thank you for registering. Please verify your email by clicking the link below:<br><br>";
        $message .= "<a href='" . $verifyUrl . "'>Verify your account</a><br><br>";
        $message .= "If you did not register, please ignore this email.<br><br>";
        $message .= "Best regards,<br>";
        $message .= "DryTech Team";


        $mail = Mailer::send($email, $subject, $message);
        echo json_encode(['success' => true, 'message' => "Thank you for registration, we have sent you a link to your email to verify your account."]);
    } else {
        echo json_encode([
            'success' => false,
            'errors' => ['general' => 'Registration failed. Please try again.']
        ]);
    }
}

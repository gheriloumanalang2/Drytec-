<?php

use Dotenv\Dotenv;

require_once '../vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();


require_once '../classes/Db.php';



if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
    $data = $_POST;
    unset($data['g-recaptcha-response']);

    if (isset($_POST['g-recaptcha-response']) && !empty($_POST['g-recaptcha-response'])) {
        $secretKey = $_ENV['SECRET_KEY'];

        $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secretKey . '&response=' . $_POST['g-recaptcha-response']);
        $response = json_decode($verifyResponse);

        if ($response->success) {
            $sql = "INSERT INTO contact_messages (full_name, email, phone, subject, address,message) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$full_name, $email, $phone, $subject, $address, $message]);
            if ($stmt) {
                $lastInsertedId = $conn->lastInsertId();

                $filePath = '../assets/image/projects/';

                $stmt = $conn->prepare("INSERT INTO projects(contact_id, location, client, contract_amount, status, is_planning) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$lastInsertedId, $address, $client, $contract_amount, 'Planning', 1]);

                if ($stmt) {
                    $projectId = $conn->lastInsertId();

                    if (!empty($_FILES['attachment']['name'][0])) {
                        foreach ($_FILES['attachment']['name'] as $index => $fileName) {
                            $tmpName = $_FILES['attachment']['tmp_name'][$index];
                            $targetPath = $filePath . basename($fileName);
                            move_uploaded_file($tmpName, $targetPath);
                            $stmtImg = $conn->prepare("INSERT INTO project_images (project_id, image_path) VALUES (?, ?)");
                            $stmtImg->execute([$projectId, $fileName]);
                        }
                    }

                    echo json_encode([
                        "status" => true,
                        'message' => "Inquiries successfully submitted"
                    ]);
                } else {
                    echo json_encode([
                        "status" => false,
                        "message" => "Failed to submit project"
                    ]);
                }
            } else {
                echo json_encode([
                    "status" => false,
                    'message' => "An error occurred while submitting your inquiry."
                ]);
            }
        } else {
            echo json_encode([
                "status" => false,
                'message' => "Inquiries failed, please verify CAPTCHA."
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            'message' => "CAPTCHA is required."
        ]);
    }
}

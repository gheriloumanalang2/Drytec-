<?php
session_start();


require_once '../classes/Db.php';

if (isset($_POST['update_profile'])) {
    extract($_POST);

    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ? ");
    $stmt->execute([$name, $email, $userId]);
    if ($stmt) {
        $_SESSION['message'] = "Profile Updated";
        header("location: ../profile");
        exit();
    }
}

if (isset($_POST['change_password'])) {
    extract($_POST);

    // Fetch current hashed password from database
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        $_SESSION['message'] = "User not found.";
        header("location: ../profile");
        exit();
    }

    // Verify current password
    if (!password_verify($current_password, $user['password'])) {
        $_SESSION['error'] = "Current password is incorrect.";
        header("location: ../profile");
        exit();
    }

    // Check if new password and confirm password match
    if ($new_password !== $confirm_password) {
        $_SESSION['error'] = "New password and confirmation do not match.";
        header("location: ../profile");
        exit();
    }

    if (strlen($new_password) < 6) {
        $_SESSION['error'] = "New password must be at least 8 characters.";
        header("location: ../profile");
        exit();
    }

    // Hash new password
    $hashedPassword = password_hash($new_password, PASSWORD_DEFAULT);

    // Update password
    $update = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $update->execute([$hashedPassword, $userId]);

    if ($update) {
        $_SESSION['message'] = "Password changed successfully.";
        header("location: ../profile");
        exit();
    } else {
        $_SESSION['error'] = "Failed to update password.";
        header("location: ../profile");
        exit();
    }
}

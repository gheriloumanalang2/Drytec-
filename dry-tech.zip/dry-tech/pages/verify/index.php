<?php
$token = $_GET['token'] ?? null;
$verified = false;

if ($token) {
    $stmt = $db->conn()->prepare("SELECT * FROM users WHERE verify_token = :token LIMIT 1");
    $stmt->bindParam(':token', $token);
    $stmt->execute();

    if ($user = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $update = $db->conn()->prepare("UPDATE users SET is_verified = 1, verify_token = NULL WHERE id = :id");
        $update->bindParam(':id', $user['id']);
        $verified = $update->execute();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Account Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card text-center shadow">
                    <div class="card-body">
                        <?php if ($verified): ?>
                            <h3 class="card-title text-success">✅ Account Verified!</h3>
                            <p class="card-text">Your account has been successfully verified. You may now log in.</p>
                            <a href="home" class="btn btn-primary">Go to Login</a>
                        <?php else: ?>
                            <h3 class="card-title text-danger">❌ Invalid or Expired Token</h3>
                            <p class="card-text">The verification link is either invalid or has already been used.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
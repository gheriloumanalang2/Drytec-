<?php

use App\Class\PathResolver;
use App\Class\Session;

$title = "Admin Profile";
$pagetitle = "Edit Profile";
include(PathResolver::basePath('pages/admin/partials/header.php'));
include(PathResolver::basePath('pages/admin/partials/topbar.php'));

$db = \App\Class\Database::getInstance();

$auth = Session::auth();

?>


<div class="tab-content" id="profileTab">
    <div class="tab-pane fade show active" id="profile" role="tabpanel">
        <div class="container-fluid py-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <?php if (isset($_SESSION['message'])): ?>
                        <div class="alert alert-success alert-dismissible fade show shadow-sm border-0" role="alert">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-check-circle-fill me-2"></i>
                                <?= htmlspecialchars($_SESSION['message']) ?>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php
                        unset($_SESSION['message']);
                    endif;
                    ?>
                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-warning alert-dismissible fade show shadow-sm border-0" role="alert">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-check-circle-fill me-2"></i>
                                <?= htmlspecialchars($_SESSION['error']) ?>
                            </div>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php
                        unset($_SESSION['error']);
                    endif;
                    ?>

                    <form action="<?= BASE_URL ?>/actions/update-profile.php" method="POST">
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Full Name</label>
                            <input type="text" name="name" value="<?= htmlspecialchars($auth['name']) ?>" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold">Email</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($auth['email']) ?>" class="form-control" required>
                        </div>
                        <input type="hidden" name="userId" value="<?= $auth['id'] ?>">
                        <button type="submit" name="update_profile" class="btn btn-primary px-4 mt-2">Save Changes</button>
                    </form>

                    <hr class="my-4">

                    <h5 class="mb-3">Change Password</h5>

                    <form action="<?= BASE_URL ?>/actions/update-profile.php" method="POST">
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">New Password</label>
                            <input type="password" name="new_password" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-bold">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                        <input type="hidden" name="userId" value="<?= $auth['id'] ?>">
                        <button type="submit" name="change_password" class="btn btn-primary px-4 mt-2">Update Password</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>



<?php include(PathResolver::basePath('pages/admin/partials/footer.php')); ?>
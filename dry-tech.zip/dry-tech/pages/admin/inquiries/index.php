<?php

$title = "Admin Inquiries";
$pagetitle = "Inquiries Page";
include(\App\Class\PathResolver::basePath('pages/admin/partials/header.php'));

?>

<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/topbar.php')); ?>


<div class="tab-content">
    <div class="tab-pane fade show active">

        <div class="card shadow-sm border-light mb-4">
            <div class="card-header text-white bg-success">
                <h4 class="card-title mb-0">Available Inquiries</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-striped">
                        <thead class="thead-light">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Subject</th>
                                <th>Complete Address</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $db = \App\Class\Database::getInstance();

                            $stmt = $db->conn()->prepare("
                                SELECT 
                                    contact_messages.*, 
                                    projects.id AS project_id,
                                    contact_messages.id as contactId,
                                    projects.location, 
                                    projects.client, 
                                    projects.contract_amount, 
                                    projects.status,
                                    project_images.image_path,
                                    projects.is_planning
                                FROM contact_messages 
                                LEFT JOIN projects ON contact_messages.id = projects.contact_id 
                                LEFT JOIN project_images ON projects.id = project_images.project_id
                                ORDER BY contact_messages.submitted_at ASC 
                            ");
                            $stmt->execute();
                            $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            $grouped = [];

                            foreach ($data as $row) {
                                $id = $row['id'];
                                if (!isset($grouped[$id])) {
                                    $grouped[$id] = $row;
                                    $grouped[$id]['image_path'] = [];
                                }

                                if (!empty($row['image_path'])) {
                                    $grouped[$id]['image_path'][] = $row['image_path'];
                                }
                            }

                            foreach ($grouped as $row) {
                                $images = htmlspecialchars(json_encode($row['image_path']));
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                    <td><?php echo htmlspecialchars($row['address']); ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-info view-message"
                                            data-id="<?php echo htmlspecialchars($row['contactId']); ?>"
                                            data-name="<?php echo htmlspecialchars($row['full_name']); ?>"
                                            data-email="<?php echo htmlspecialchars($row['email']); ?>"
                                            data-phone="<?php echo htmlspecialchars($row['phone']); ?>"
                                            data-subject="<?php echo htmlspecialchars($row['subject']); ?>"
                                            data-address="<?php echo htmlspecialchars($row['address']); ?>"
                                            data-message="<?php echo htmlspecialchars($row['message']); ?>"
                                            data-client="<?php echo htmlspecialchars($row['client']); ?>"
                                            data-amount="<?php echo htmlspecialchars(number_format($row['contract_amount'], 2)); ?>"
                                            data-images='<?php echo json_encode($row['image_path'] ?? []); ?>'
                                            data-approved="<?php echo $row['is_planning']; ?>">
                                            <i class="fas fa-eye"></i>
                                        </button>

                                        <button class="btn btn-danger btn-sm delete" data-ref="<?php echo htmlspecialchars($row['id']); ?>"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="messageModalLabel">Inquiry Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <dl class="row">
                    <dt class="col-sm-3 mb-3"><strong>Full Name</strong></dt>
                    <dd class="col-sm-9" id="inquiryName"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Email</strong></dt>
                    <dd class="col-sm-9" id="inquiryEmail"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Phone</strong></dt>
                    <dd class="col-sm-9" id="inquiryPhone"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Subject</strong></dt>
                    <dd class="col-sm-9" id="inquirySubject"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Address</strong></dt>
                    <dd class="col-sm-9" id="inquiryAddress"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Contract Amount</strong></dt>
                    <dd class="col-sm-9" id="inquiryAmount"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Client</strong></dt>
                    <dd class="col-sm-9" id="inquiryClient"></dd>

                    <dt class="col-sm-3 mb-3"><strong>Message</strong></dt>
                    <dd class="col-sm-9" id="inquiryMessage"></dd>
                    <dt class="col-sm-3 mb-3"><strong>Images</strong></dt>
                    <dd class="col-sm-9" id="inquiryImages"></dd>
                </dl>
            </div>
            <div class="modal-footer">
                <form action="<?= BASE_URL ?>/actions/approve-inquiry.php" method="POST">
                    <input type="hidden" name="contactid" id="contactid">
                    <button type="submit" class="btn btn-primary">Approve</button>
                </form>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        $(document).on('click', '.view-message', function() {
            // Set other message details
            $('#inquiryName').text($(this).data('name'));
            $('#inquiryEmail').text($(this).data('email'));
            $('#inquiryPhone').text($(this).data('phone'));
            $('#inquirySubject').text($(this).data('subject'));
            $('#inquiryAddress').text($(this).data('address'));
            $('#inquiryMessage').text($(this).data('message'));
            $('#inquiryAmount').text($(this).data('amount'))
            $('#inquiryClient').text($(this).data('client'))
            $('#contactid').val($(this).data('id'))
            var imagesData = $(this).data('images');
            console.log(imagesData);


            var images = Array.isArray(imagesData) ? imagesData : JSON.parse(imagesData);

            var imagesHtml = '';
            if (images && images.length > 0) {
                images.forEach(function(image) {
                    imagesHtml += '<img src="<?= BASE_URL ?>/assets/image/projects/' + image + '" alt="Project Image" class="img-fluid mb-2 w-25">';
                });
            } else {
                imagesHtml = '<p>No images available.</p>';
            }

            var isApproved = $(this).data('approved');
            if (isApproved) {
                $('#messageModal button[type="submit"]').prop('disabled', true).text('Inquiry Already Approved and Projects has been moved to Planning, please check.');
            } else {
                $('#messageModal button[type="submit"]').prop('disabled', false).text('Approve');
            }
            $('#inquiryImages').html(imagesHtml);
            $('#messageModal').modal('show');
        });



        $(document).on('click', '.delete', function() {
            var id = $(this).data('ref');
            var confirmed = confirm("Are you sure you want to remove this inquiry?");
            if (confirmed) {
                $.post({
                    url: '<?= BASE_URL ?>/actions/delete.php',
                    data: {
                        id: id,
                        action: 'inquiry'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert('Inquiry deleted successfully.');
                            $(this).closest('tr').remove();
                            setTimeout(() => {
                                location.reload()
                            }, 1500);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting inquiry.');
                        console.error(error);
                    }
                });
            } else {
                console.log("Deletion cancelled.");
            }
        });

    });
</script>

<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/footer.php')); ?>
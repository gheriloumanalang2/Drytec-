<?php

$title = "All Users";
$pagetitle = "Account Management Page";
include(\App\Class\PathResolver::basePath('pages/admin/partials/header.php'));

?>

<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/topbar.php')); ?>


<!-- Add Admin Modal -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" action="<?= BASE_URL ?>/actions/add_admin.php" id="addAdminForm">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="addUserModalLabel">Add New Admin</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="adminName" class="form-label">Full Name</label>
                        <input type="text" id="adminName" name="name" class="form-control">
                        <div class="invalid-feedback" id="nameError">Please enter a name.</div>
                    </div>
                    <div class="mb-3">
                        <label for="adminEmail" class="form-label">Email Address</label>
                        <input type="email" id="adminEmail" name="email" class="form-control">
                        <div class="invalid-feedback" id="emailError">Please enter a valid email.</div>
                    </div>
                    <div class="mb-3">
                        <label for="adminPassword" class="form-label">Password</label>
                        <input type="password" id="adminPassword" name="password" class="form-control" minlength="6">
                        <div class="invalid-feedback" id="passwordError">Password must be at least 6 characters.</div>
                    </div>
                    <div class="mb-3">
                        <label for="adminConfirmPassword" class="form-label">Confirm Password</label>
                        <input type="password" id="adminConfirmPassword" name="confirm_password" class="form-control" minlength="6">
                        <div class="invalid-feedback" id="confirmError">Passwords do not match.</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Create Admin</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>


<div class="tab-content">
    <div class="tab-pane fade show active">

        <div class="card shadow-sm border-light mb-4">
            <div class="card-header text-white bg-primary">
                <h4 class="card-title mb-0">
                    Admin Accounts
                    <button class="btn btn-success float-end" data-bs-toggle="modal" data-bs-target="#addUserModal">
                        Add New Admin
                    </button>

                </h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-striped">
                        <thead class="thead-light">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $db = \App\Class\Database::getInstance();

                            $stmt = $db->conn()->prepare('SELECT * FROM users WHERE id != ? AND role = "Admin" ');
                            $stmt->execute([$_SESSION['user_id']]);
                            $data = $stmt->fetchAll();

                            if ($stmt->rowCount() > 0) {
                                foreach ($data as $index => $row) {
                                    $userId = htmlspecialchars($row['id']);
                                    $modalId = 'activateModal' . $index;
                                    $modalActivateId = 'activateModal' . $index;
                                    $modalDeactivateId = 'deactivateModal' . $index;
                                    $modalDeleteId = 'deleteModal' . $index;
                                    echo "<tr>";
                                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                                    echo "<td>";

                                    if ($row['is_active']) {
                                        echo "<button class='btn btn-warning btn-sm' data-bs-toggle='modal' data-bs-target='#$modalDeactivateId'>
                                                <i class='fas fa-user-slash'></i> Deactivate
                                            </button>";
                                        echo "
                                        <div class='modal fade' id='$modalDeactivateId' tabindex='-1' aria-labelledby='{$modalDeactivateId}Label' aria-hidden='true'>
                                            <div class='modal-dialog'>
                                                <div class='modal-content'>
                                                    <div class='modal-header bg-warning text-dark'>
                                                        <h5 class='modal-title' id='{$modalDeactivateId}Label'>Deactivate Account</h5>
                                                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                    </div>
                                                    <form action='" . BASE_URL . "/actions/deactivate_user.php' method='POST'>
                                                        <div class='modal-body'>
                                                            <input type='hidden' name='user_id' value='$userId'>
                                                            <p>Are you sure you want to deactivate this account?</p>
                                                        </div>
                                                        <div class='modal-footer'>
                                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                            <button type='submit' class='btn btn-warning'>Deactivate</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>";
                                    } else {
                                        echo "<button class='btn btn-success btn-sm' data-bs-toggle='modal' data-bs-target='#$modalId'>
                                                <i class='fas fa-check'></i> Activate
                                            </button>";

                                        echo "
                                        <div class='modal fade' id='$modalId' tabindex='-1' aria-labelledby='{$modalId}Label' aria-hidden='true'>
                                            <div class='modal-dialog'>
                                                <div class='modal-content'>
                                                    <div class='modal-header bg-success text-white'>
                                                        <h5 class='modal-title' id='{$modalId}Label'>Activate Account</h5>
                                                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                    </div>
                                                    <form action='" . BASE_URL . "/actions/activate_user.php' method='POST'>
                                                        <div class='modal-body'>
                                                            <input type='hidden' name='user_id' value='$userId'>
                                                            <p>Are you sure you want to activate this account?</p>
                                                        </div>
                                                        <div class='modal-footer'>
                                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                            <button type='submit' class='btn btn-success'>Activate</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>";
                                    }

                                    echo "<button class='btn btn-danger btn-sm' data-bs-toggle='modal' data-bs-target='#$modalDeleteId'>
                                            <i class='fas fa-trash-alt'></i> Delete
                                        </button>";
                                    echo "
                                        <div class='modal fade' id='$modalDeleteId' tabindex='-1' aria-labelledby='{$modalDeleteId}Label' aria-hidden='true'>
                                            <div class='modal-dialog'>
                                                <div class='modal-content'>
                                                    <div class='modal-header bg-danger text-white'>
                                                        <h5 class='modal-title' id='{$modalDeleteId}Label'>Delete Account</h5>
                                                        <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                    </div>
                                                    <form action='" . BASE_URL . "/actions/delete_user.php' method='POST'>
                                                        <div class='modal-body'>
                                                            <input type='hidden' name='user_id' value='$userId'>
                                                            <p>Are you sure you want to permanently delete this user account?</p>
                                                        </div>
                                                        <div class='modal-footer'>
                                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                            <button type='submit' class='btn btn-danger'>Delete</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>";

                                    echo "</td>";
                                    echo "</tr>";
                                }
                            }
                            ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        $(document).on('click', '.delete', function() {
            var id = $(this).data('ref');
            var confirmed = confirm("Are you sure you want to remove this user?");
            if (confirmed) {
                $.post({
                    url: '<?= BASE_URL ?>/actions/delete.php',
                    data: {
                        id: id,
                        action: 'user'
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            alert('Inquiry deleted successfully.');
                            $(this).closest('tr').remove();
                            setTimeout(() => {
                                location.reload()
                            }, 1500);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting inquiry.');
                        console.error(error);
                    }
                });
            } else {
                console.log("Deletion cancelled.");
            }
        });

    });
</script>

<script>
    document.getElementById('addAdminForm').addEventListener('submit', function(e) {
        let valid = true;

        const name = document.getElementById('adminName');
        const email = document.getElementById('adminEmail');
        const password = document.getElementById('adminPassword');
        const confirm = document.getElementById('adminConfirmPassword');

        // Reset previous state
        [name, email, password, confirm].forEach(input => {
            input.classList.remove('is-invalid');
        });

        if (name.value.trim() === '') {
            name.classList.add('is-invalid');
            valid = false;
        }

        if (!email.value.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
            email.classList.add('is-invalid');
            valid = false;
        }

        if (password.value.length < 6) {
            password.classList.add('is-invalid');
            valid = false;
        }

        if (password.value !== confirm.value) {
            confirm.classList.add('is-invalid');
            valid = false;
        }

        if (!valid) {
            e.preventDefault();
        }
    });
</script>


<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/footer.php')); ?>
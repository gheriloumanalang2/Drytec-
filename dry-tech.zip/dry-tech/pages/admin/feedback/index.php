<?php

use App\Class\PathResolver;

$title = "Admin | Feedbacks";
$pagetitle = "Feedbacks";
include(PathResolver::basePath('pages/admin/partials/header.php'));
include(PathResolver::basePath('pages/admin/partials/topbar.php'));

$db = \App\Class\Database::getInstance();

?>

<div class="tab-content" id="projectTabContent">
    <div class="tab-pane fade show active" id="ongoing" role="tabpanel">
        <div class="container-fluid py-4">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="dataTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Message</th>
                                    <th>Created At</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $feedbacks = $db->conn()->query("SELECT * FROM ratings WHERE status != 'Disapprove' ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($feedbacks as $index => $feedback) {
                                    $message = htmlspecialchars($feedback['comments']);
                                    $truncatedMessage = mb_strimwidth($message, 0, 100, '...');
                                    $viewModalId = "viewModal" . $index;
                                    $approveModalId = "approveModal" . $index;
                                    $disapproveModalId = "disapproveModal" . $index;

                                    echo "<tr>";
                                    echo "<td>" . ($index + 1) . "</td>";
                                    echo "<td>" . htmlspecialchars($feedback['name']) . "</td>";
                                    echo "<td>" . htmlspecialchars($feedback['email']) . "</td>";
                                    echo "<td>" . $truncatedMessage . "</td>";
                                    echo "<td>" . htmlspecialchars($feedback['created_at']) . "</td>";

                                    echo "<td>
                                        <button class='btn btn-info btn-sm text-white' data-bs-toggle='modal' data-bs-target='#$viewModalId'>
                                            <i class='fas fa-eye'></i> View
                                        </button>";

                                    if ($feedback['status'] !== 'Approve') {
                                        echo "<button class='btn btn-success btn-sm text-white' data-bs-toggle='modal' data-bs-target='#$approveModalId'>
                                            <i class='fas fa-check'></i> Approve
                                        </button>";
                                    }

                                    if ($feedback['status'] !== 'Disapprove') {
                                        echo "<button class='btn btn-danger btn-sm text-white' data-bs-toggle='modal' data-bs-target='#$disapproveModalId'>
                                            <i class='fas fa-times'></i> Disapprove
                                        </button>";
                                    }

                                    echo "</td>";
                                    echo "</tr>";

                                    // View Modal
                                    echo "
                                    <div class='modal fade' id='$viewModalId' tabindex='-1' aria-labelledby='{$viewModalId}Label' aria-hidden='true'>
                                        <div class='modal-dialog modal-lg'>
                                            <div class='modal-content'>
                                                <div class='modal-header' style='background-color:rgb(5, 55, 237); color: white;'>
                                                    <h5 class='modal-title' id='{$viewModalId}Label'>Customer Feedback</h5>
                                                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                </div>
                                                <div class='modal-body'>
                                                    <div class='mb-3'>
                                                        <h6 class='text-muted'>Feedback Details</h6>
                                                        <div class='border p-3 rounded-3'>
                                                            <strong>Name:</strong> " . htmlspecialchars($feedback['name']) . "<br>
                                                            <strong>Email:</strong> " . htmlspecialchars($feedback['email']) . "<br>
                                                            <strong>Created At:</strong> " . htmlspecialchars($feedback['created_at']) . "<br>
                                                        </div>
                                                    </div>
                                                    <div class='mb-3'>
                                                        <h6 class='text-muted'>Message</h6>
                                                        <div class='border p-3 rounded-3'>
                                                            <p>" . nl2br(htmlspecialchars($feedback['comments'])) . "</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class='modal-footer'>
                                                    <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>";

                                    // Approve Modal
                                    echo "
                                    <div class='modal fade' id='$approveModalId' tabindex='-1' aria-labelledby='{$approveModalId}Label' aria-hidden='true'>
                                        <div class='modal-dialog'>
                                            <div class='modal-content'>
                                                <div class='modal-header bg-success text-white'>
                                                    <h5 class='modal-title' id='{$approveModalId}Label'>Approve Feedback</h5>
                                                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                </div>
                                                <div class='modal-body'>
                                                    <form action='" . BASE_URL . "/actions/approve.php' method='POST'>
                                                        <input type='hidden' name='feedback_id' value='" . $feedback['id'] . "'>
                                                        <p>Are you sure you want to approve this feedback?</p>
                                                        <div class='modal-footer'>
                                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                            <button type='submit' class='btn btn-success'>Approve</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>";

                                    echo "
                                    <div class='modal fade' id='$disapproveModalId' tabindex='-1' aria-labelledby='{$disapproveModalId}Label' aria-hidden='true'>
                                        <div class='modal-dialog'>
                                            <div class='modal-content'>
                                                <div class='modal-header bg-danger text-white'>
                                                    <h5 class='modal-title' id='{$disapproveModalId}Label'>Disapprove Feedback</h5>
                                                    <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                                                </div>
                                                <div class='modal-body'>
                                                    <form action='" . BASE_URL . "/actions/disapprove.php' method='POST'>
                                                        <input type='hidden' name='feedback_id' value='" . $feedback['id'] . "'>
                                                        <p>Are you sure you want to disapprove this feedback?</p>
                                                        <div class='modal-footer'>
                                                            <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>Cancel</button>
                                                            <button type='submit' class='btn btn-danger'>Disapprove</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>";
                                }

                                ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include(PathResolver::basePath('pages/admin/partials/footer.php')); ?>
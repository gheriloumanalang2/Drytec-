<?php

$title = "Admin Conversation";
$pagetitle = "Conversations";
include(\App\Class\PathResolver::basePath('pages/admin/partials/header.php'));

$conversations = $db->conn()->prepare("
    SELECT 
        c.id AS conversation_id, 
        u.id AS user_id, 
        u.name AS user_name, 
        c.created_at AS conversation_created_at,
        COUNT(m.id) AS total_messages, 
        SUM(CASE WHEN m.is_read = 0 THEN 1 ELSE 0 END) AS unread_messages,
        MAX(m.created_at) AS last_message_time
    FROM conversations c
    LEFT JOIN conversation_user cu ON cu.conversation_id = c.id
    LEFT JOIN users u ON u.id = cu.user_id
    LEFT JOIN messages m ON m.conversation_id = c.id AND m.sender_id = u.id
    GROUP BY c.id, u.id
    ORDER BY unread_messages DESC, last_message_time DESC
");
$conversations->execute();
$data = $conversations->fetchAll(PDO::FETCH_ASSOC);

?>

<style>
    .chat-body {
        max-height: 500px;
        overflow-y: auto;
        padding: 10px;
        background-color: #f9f9f9;
    }

    .chat-bubble {
        padding: 10px 15px;
        border-radius: 15px;
        position: relative;
        font-size: 0.95rem;
    }

    .chat-bubble.sender {
        background-color: #007bff;
        color: #fff;
        border-bottom-right-radius: 0;
    }

    .chat-bubble.receiver {
        background-color: #e9ecef;
        color: #333;
        border-bottom-left-radius: 0;
    }

    .chat-time {
        font-size: 0.75rem;
        margin-top: 5px;
        text-align: right;
    }
</style>

<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/topbar.php')); ?>

<div class="container-fluid">
    <div class="row">
        <!-- Sidebar with Conversations List -->
        <div class="col-md-4 col-lg-3">
            <div class="card shadow-sm border-light mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Conversations</h5>
                </div>
                <div class="card-body">
                    <div class="list-group" id="conversationList">
                        <?php if ($conversations->rowCount() > 0): ?>
                            <?php foreach ($data as $row): ?>
                                <a href="conversations/<?= $row['conversation_id']; ?>"
                                    class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                    <?= ($row['unread_messages'] > 0) ? 'bg-secondary text-white' : '' ?>">
                                    <div>
                                        <strong><?= htmlspecialchars($row['user_name']); ?></strong><br>
                                    </div>

                                    <?php if ($row['unread_messages'] > 0): ?>
                                        <span class="badge badge-danger badge-pill bg-success"><?= $row['unread_messages']; ?></span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No conversations available.</p>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>

        <!-- Message Content Area -->
        <div class="col-md-8 col-lg-9">
            <div class="card shadow-sm border-light mb-4" id="conversationContent">
                <div class="card-header">
                    <h5 class="card-title mb-0">Select a Conversation</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted">Please select a conversation to view its messages.</p>
                </div>
            </div>
        </div>
    </div>
</div>



<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/footer.php')); ?>
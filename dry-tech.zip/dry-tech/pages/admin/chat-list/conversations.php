<?php

$title = "Admin Conversation";
$pagetitle = "Chat";
include(\App\Class\PathResolver::basePath('pages/admin/partials/header.php'));
$currentUserId = $_SESSION['user_id'];
$getId = $_GET['id'];

$conversations = $db->conn()->prepare("
    SELECT 
        c.id AS conversation_id, 
        u.id AS user_id, 
        u.name AS user_name, 
        c.created_at AS conversation_created_at,
        COUNT(m.id) AS total_messages, 
        SUM(CASE WHEN m.is_read = 0 THEN 1 ELSE 0 END) AS unread_messages,
        MAX(m.created_at) AS last_message_time
    FROM conversations c
    LEFT JOIN conversation_user cu ON cu.conversation_id = c.id
    LEFT JOIN users u ON u.id = cu.user_id
    LEFT JOIN messages m ON m.conversation_id = c.id AND m.sender_id = u.id
    GROUP BY c.id, u.id
    ORDER BY unread_messages DESC, last_message_time DESC
");
$conversations->execute();
$data = $conversations->fetchAll(PDO::FETCH_ASSOC);

$update = "UPDATE messages SET is_read = 1  WHERE conversation_id = ? ";
$stmtUpdate = $db->conn()->prepare($update);
$stmtUpdate->execute([$getId]);

$selectedUser = '';
foreach ($data as $row) {
    if ($getId == $row['conversation_id']) {
        $selectedUser = $row['user_name'];
        break;
    }
}

?>

<style>
    .bg-active {
        color: #fff;
        background-color: lightblue;
    }

    #chat-box {
        height: 500px;
        overflow-y: auto;
        padding: 15px;
        background-color: #f1f1f1;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .message {
        max-width: 60%;
        padding: 10px 15px;
        border-radius: 10px;
        word-wrap: break-word;
        font-size: 14px;
        line-height: 1.4;
    }

    .message-sender {
        align-self: flex-end;
        background-color: #d1e7dd;
        color: #000;
        text-align: left;
    }

    .message-receiver {
        align-self: flex-start;
        background-color: #e9ecef;
        color: #000;
        text-align: left;
    }
</style>

<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/topbar.php')); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-4 col-lg-3">
            <div class="card shadow-sm border-light mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Conversations</h5>
                </div>
                <div class="card-body">
                    <div class="list-group" id="conversationList">
                        <?php if ($conversations->rowCount() > 0): ?>
                            <?php foreach ($data as $row): ?>
                                <a href="<?= $row['conversation_id']; ?>"
                                    class="list-group-item list-group-item-action d-flex justify-content-between align-items-center
                                    <?= ($row['unread_messages'] > 0) ? 'bg-secondary text-white' : '' ?>
                                    ">
                                    <div>
                                        <strong><?= htmlspecialchars($row['user_name']); ?></strong><br>
                                    </div>

                                    <?php if ($row['unread_messages'] > 0): ?>
                                        <span class="badge badge-danger badge-pill bg-success"><?= $row['unread_messages']; ?></span>
                                    <?php endif; ?>
                                </a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p>No conversations available.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-8 col-lg-9">
            <div class="card mb-4" id="conversationContent">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?= htmlspecialchars($selectedUser); ?></h5>
                </div>
                <div class="card-body" id="chat-box">
                </div>
                <div class="input-group absolute top-0">
                    <input type="text" class="form-control" id="messageInput" placeholder="Type your message...">
                    <button class="btn btn-primary" id="sendMessageBtn">Send</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="imagePreviewModal" tabindex="-1" role="dialog" aria-labelledby="imagePreviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content bg-dark">
            <div class="modal-body p-0">
                <img src="" id="previewImage" class="img-fluid w-100 rounded" alt="Preview">
            </div>
        </div>
    </div>
</div>



<script>
    var conversationId = '<?= $getId ?>';

    Pusher.logToConsole = true;
    var pusher = new Pusher('<?= $_ENV['PUSHER_APP_KEY'] ?>', {
        cluster: '<?= $_ENV['PUSHER_APP_CLUSTER'] ?>'
    });

    var channel = pusher.subscribe('conversation.' + conversationId);

    $(document).ready(function() {
        $.ajax({
            url: '<?= BASE_URL ?>/actions/fetch_messages.php',
            type: 'GET',
            data: {
                conversation_id: conversationId
            },
            dataType: 'json',
            success: function(response) {
                console.log(response);

                if (response.status === 'success') {
                    const messages = response.messages;
                    const currentUserId = '<?= $currentUserId ?>';

                    if (messages.length === 0) {
                        $('#chat-box').html('<div class="text-center text-muted p-3">Welcome to drytec! Start sending message to admin.</div>');
                        return;
                    }

                    const messageHtml = messages.map((message) => {
                        const isSender = message.sender_id == currentUserId;
                        const alignment = isSender ? 'text-end' : 'text-start';
                        const bubbleClass = isSender ? 'bg-primary text-white' : 'bg-light';
                        const date = new Date(message.created_at);
                        const formattedTime = date.toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit'
                        });

                        let messageContent = `
                    <div class="${alignment} mb-2">
                        <div class="d-inline-block ${bubbleClass} rounded p-2" style="max-width: 80%;">`;
                        if (message.message && message.message.trim() !== '') {
                            messageContent += `<span>${escapeHtml(message.message)}</span>`;
                        }

                        if (message.attachment_path) {
                            const fileExt = message.attachment_name.split('.').pop().toLowerCase();
                            const baseUrl = '<?= BASE_URL ?>/assets/' + message.attachment_path;

                            if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'].includes(fileExt)) {
                                messageContent += `
                            <div class="mt-2">
                                <img src="${baseUrl}" alt="${escapeHtml(message.attachment_name)}" 
                                    class="img-fluid rounded previewable-image" 
                                    style="max-width: 150px; cursor: pointer;" 
                                    data-full="${baseUrl}">
                            </div>`;
                            } else {
                                let fileIcon = 'bi-file';
                                if (['doc', 'docx'].includes(fileExt)) {
                                    fileIcon = 'bi-file-word';
                                } else if (['xls', 'xlsx', 'csv'].includes(fileExt)) {
                                    fileIcon = 'bi-file-excel';
                                } else if (['pdf'].includes(fileExt)) {
                                    fileIcon = 'bi-file-pdf';
                                } else if (['zip', 'rar', '7z'].includes(fileExt)) {
                                    fileIcon = 'bi-file-zip';
                                }

                                messageContent += `
                            <div class="mt-2">
                                <a href="${baseUrl}" target="_blank" class="d-flex align-items-center text-decoration-none ${isSender ? 'text-white' : 'text-primary'}">
                                    <i class="bi ${fileIcon} me-2"></i>
                                    <span class="text-truncate" style="max-width: 150px;">${escapeHtml(message.attachment_name)}</span>
                                </a>
                            </div>`;
                            }
                        }


                        messageContent += `
                        </div>
                        <small class="text-muted d-block">${formattedTime}</small>
                    </div>`;

                        return messageContent;
                    }).join('');

                    $('#chat-box').html(messageHtml);
                    $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
                }
            },
            error: function(xhr, status, error) {
                console.error('Failed to load messages: ' + error);
                $('#chat-box').html('<div class="text-center text-danger p-3">Failed to load messages</div>');
            }
        });

        channel.bind('message.sent', function(data) {
            const currentUserId = '<?= $currentUserId ?>';
            const isSender = data.sender_id == currentUserId;
            const alignment = isSender ? 'text-end' : 'text-start';
            const bubbleClass = isSender ? 'bg-primary text-white' : 'bg-light';

            let messageHTML = `
        <div class="${alignment} mb-2">
            <div class="d-inline-block ${bubbleClass} rounded p-2" style="max-width: 80%;">`;

            if (data.message && data.message.trim() !== '') {
                messageHTML += `<span>${escapeHtml(data.message)}</span>`;
            }

            if (data.attachment_url) {
                const fileName = data.attachment_name || 'attachment';
                const fileExt = fileName.split('.').pop().toLowerCase();
                let fileIcon = 'bi-file';

                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'].includes(fileExt)) {
                    fileIcon = 'bi-file-image';
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon = 'bi-file-word';
                } else if (['xls', 'xlsx', 'csv'].includes(fileExt)) {
                    fileIcon = 'bi-file-excel';
                } else if (['pdf'].includes(fileExt)) {
                    fileIcon = 'bi-file-pdf';
                } else if (['zip', 'rar', '7z'].includes(fileExt)) {
                    fileIcon = 'bi-file-zip';
                }

                messageHTML += `
        <div class="mt-2">
            <a href="${data.attachment_url}" target="_blank" class="d-flex align-items-center text-decoration-none ${isSender ? 'text-white' : 'text-primary'}">
                <i class="bi ${fileIcon} me-2"></i>
                <span class="text-truncate" style="max-width: 150px;">${escapeHtml(fileName)}</span>
            </a>
        </div>`;
            }

            messageHTML += `
            </div>
            <small class="text-muted d-block">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>
        </div>`;

            $('#chat-box').append(messageHTML);
            $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
        });

        $('#sendMessageBtn').click(function() {
            var messageText = $('#messageInput').val();
            if (messageText.trim() !== '') {
                if (messageText) {
                    $.ajax({
                        url: '<?= BASE_URL ?>/actions/send_message.php',
                        type: 'POST',
                        data: {
                            conversation_id: conversationId,
                            sender_id: '<?= $currentUserId ?>',
                            message: messageText
                        },
                        dataType: 'json',
                        success: function(response) {
                            $('#messageInput').val('');
                        },
                        error: function(xhr, status, error) {
                            console.error('Message send failed: ' + error);
                        }
                    });
                }
            }
        });

        const escapeHtml = (unsafe) => {
            return unsafe
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/\n/g, "<br>");
        };

        $('#messageInput').keypress(function(e) {
            if (e.which == 13) {
                $('#sendMessageBtn').click();
            }
        });
    });

    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('previewable-image')) {
            const fullImgSrc = e.target.getAttribute('data-full');
            const modalImg = document.getElementById('previewImage');
            modalImg.src = fullImgSrc;
            $('#imagePreviewModal').modal('show');
        }
    });
</script>


<?php include(\App\Class\PathResolver::basePath('pages/admin/partials/footer.php')); ?>
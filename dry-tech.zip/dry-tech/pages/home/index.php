<?php
include __DIR__ . '/../partials/header.php';
$currentUserId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

?>


<section class="hero-section" id="home">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <h1 class="display-3 fw-bold mb-4">Excellence in <span class="text-primary-custom">Construction</span></h1>
                <p class="lead mb-5">Here at Drytec Construction Services we strive to meet the changing needs of our clients with quality services delivered by experienced and dedicated professionals.</p>
                <div class="d-flex gap-3">
                    <a href="#services" class="btn btn-warning btn-lg px-4 fw-bold">Our Services</a>
                    <?php
                    if (!isset($currentUserId)):
                    ?>
                        <button type="button" data-bs-toggle="modal" data-bs-target="#loginOrRegisterModal" class="btn btn-outline-light btn-lg px-4">Register Now</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="loginOrRegisterModal" tabindex="-1" aria-labelledby="loginOrRegisterModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginOrRegisterModalLabel">Start using Drytec</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="message_reg"></div>
                <div class="tab-content" id="authTabsContent">
                    <div class="tab-pane fade show active" id="login-tab-pane" role="tabpanel" aria-labelledby="login-tab" tabindex="0">
                        <h6 class="text-center mb-4">Register Now</h6>
                        <form id="registerForm" autocomplete="off">
                            <div class="mb-3">
                                <input type="text" class="form-control restrict-text" id="firstName" name="firstName"
                                    placeholder="Enter your firstname" pattern="[A-Za-z\s]+" title="Only letters and spaces allowed">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control restrict-text" id="middleName" name="middleName"
                                    placeholder="Enter your middlename" pattern="[A-Za-z\s]+" title="Only letters and spaces allowed">
                            </div>
                            <div class="mb-3">
                                <input type="text" class="form-control restrict-text" id="lastName" name="lastName"
                                    placeholder="Enter your lastname" pattern="[A-Za-z\s]+" title="Only letters and spaces allowed">
                            </div>
                            <div class="mb-3">
                                <input type="email" class="form-control" id="email" name="email" placeholder="Email address">
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password">
                            </div>
                            <button type="submit" id="regBtn" class="btn btn-primary w-100">Register Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- about page -->
<section class="section-padding" id="about">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6 mb-4 mb-lg-0">
                <img src="assets/image/Picture1.jpg" alt="About Drytec Construction" class="img-fluid rounded shadow">
            </div>
            <div class="col-lg-6">
                <h6 class="text-primary-custom fw-bold">ABOUT US</h6>
                <h2 class="display-5 fw-bold mb-4">Building Excellence, Delivering Trust</h2>
                <p class="lead mb-4">At Drytec Construction Services, we have gained the trust and confidence of numerous valued clients through our commitment to quality workmanship.</p>
                <p class="mb-4">With years of industry experience, our team of dedicated professionals is committed to delivering exceptional construction services that meet and exceed client expectations. We combine technical expertise with innovative solutions to bring your projects to life.</p>
                <div class="row mb-4">
                    <div class="col-6">
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-check-circle-fill text-primary-custom me-2"></i>
                            <span>Quality Assurance</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-check-circle-fill text-primary-custom me-2"></i>
                            <span>Expert Engineers</span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-check-circle-fill text-primary-custom me-2"></i>
                            <span>Safety First</span>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <i class="bi bi-check-circle-fill text-primary-custom me-2"></i>
                            <span>On-time Delivery</span>
                        </div>
                    </div>
                </div>
                <a href="#services" class="btn btn-warning px-4 py-3 fw-bold lg-w-100">Discover Our Services</a>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="section-padding bg-light-custom" id="services">
    <div class="container">
        <div class="row text-center mb-5">
            <div class="col-lg-6 mx-auto">
                <h6 class="text-primary-custom fw-bold">OUR SERVICES</h6>
                <h2 class="display-5 fw-bold">Our Eight-Wheel Professional Capabilities</h2>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-building service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Engineering</h5>
                        <p class="card-text">Comprehensive engineering solutions delivered by experienced professionals.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-file-earmark-text service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Project Contracts</h5>
                        <p class="card-text">Transparent and efficient project contract management.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-cart-check service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Procurement</h5>
                        <p class="card-text">Strategic procurement services to optimize project resources.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-check2-circle service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Commissioning</h5>
                        <p class="card-text">Expert commissioning and start-up services for all projects.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-shield-check service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Safety & Environment</h5>
                        <p class="card-text">Prioritizing safety standards and environmental responsibility.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-people service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Construction Management</h5>
                        <p class="card-text">Professional oversight of all construction processes.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-box-seam service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Material Management</h5>
                        <p class="card-text">Efficient management of construction materials and resources.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="card service-card border-0 shadow-sm p-4">
                    <div class="card-body text-center">
                        <i class="bi bi-award service-icon"></i>
                        <h5 class="card-title fw-bold mb-3">Quality Assurance</h5>
                        <p class="card-text">Rigorous quality control throughout the project lifecycle.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding" id="projects">
    <div class="container">
        <div class="row text-center mb-5">
            <div class="col-lg-6 mx-auto">
                <h6 class="text-primary-custom fw-bold">OUR PROJECTS</h6>
                <h2 class="display-5 fw-bold">Our Recent Accomplishments</h2>
                <p class="lead">Showcasing our commitment to excellence through successful project delivery.</p>
            </div>
        </div>
        <div class="row g-4">
            <?php
            $projects = $db->conn()->query("SELECT * FROM projects WHERE status != 'Planning' ")->fetchAll(PDO::FETCH_ASSOC);
            if (empty($projects)) {
                echo '<p class="text-center text-muted">No completed projects at the moment.</p>';
            } else {
                foreach ($projects as $project) {
                    $imagesStmt = $db->conn()->prepare("SELECT image_path FROM project_images WHERE project_id = ?");
                    $imagesStmt->execute([$project['id']]);
                    $images = $imagesStmt->fetchAll(PDO::FETCH_COLUMN);
                    if (empty($images)) continue;

                    // Create unique IDs for each carousel
                    $carouselId = 'projectCarousel' . $project['id'];
            ?>
                    <div class="col-md-6 col-lg-6">
                        <div class="card h-100">
                            <!-- Bootstrap 5.3 Carousel -->
                            <div id="<?php echo $carouselId; ?>" class="carousel slide" data-bs-ride="carousel">
                                <!-- Carousel indicators -->
                                <div class="carousel-indicators">
                                    <?php for ($i = 0; $i < count($images); $i++) : ?>
                                        <button type="button"
                                            data-bs-target="#<?php echo $carouselId; ?>"
                                            data-bs-slide-to="<?php echo $i; ?>"
                                            <?php echo ($i === 0) ? 'class="active" aria-current="true"' : ''; ?>
                                            aria-label="Slide <?php echo $i + 1; ?>">
                                        </button>
                                    <?php endfor; ?>
                                </div>

                                <!-- Carousel items -->
                                <div class="carousel-inner" style="height: 400px;">
                                    <?php foreach ($images as $index => $img) : ?>
                                        <div class="carousel-item <?php echo ($index === 0) ? 'active' : ''; ?>" style="height: 400px;">
                                            <img src="<?= asset('assets/image/projects/') ?><?php echo $img; ?>"
                                                class="d-block mx-auto"
                                                style="width: 100%; height: 400px; object-fit: cover;"
                                                alt="Project Image <?php echo $index + 1; ?>">
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <!-- Carousel controls -->
                                <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo $carouselId; ?>" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button" data-bs-target="#<?php echo $carouselId; ?>" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>

                            <div class="card-body">
                                <h6 class="card-title text-center"><?php echo htmlspecialchars($project['title']); ?></h6>
                                <h6 class="text-center">Client: <?php echo htmlspecialchars($project['client']); ?></h6>
                                <h6 class="text-center">
                                    <span class="badge bg-<?php echo $project['status'] === "Completed" ? 'success' : 'warning'; ?>">
                                        <?php echo htmlspecialchars($project['status']); ?>
                                    </span>
                                </h6>
                            </div>
                        </div>
                    </div>
            <?php }
            } ?>
        </div>

        <?php if (isset($_SESSION['user_id'])): ?>

            <div class="text-center mt-5">
                <a href="#contact" class="btn btn-warning px-4 py-3 fw-bold">Start Your Project With Us</a>
            </div>
        <?php endif; ?>

    </div>
</section>



<!-- Clients Section -->
<section class="section-padding bg-light-custom" id="clients">
    <div class="container">
        <div class="row text-center mb-5">
            <div class="col-lg-6 mx-auto">
                <h6 class="text-primary-custom fw-bold">SOME OF OUR CLIENTS</h6>
                <h2 class="display-5 fw-bold">Trusted by Industry Leaders</h2>
                <p class="lead">We are proud to have worked with these esteemed organizations.</p>
            </div>
        </div>
        <div class="row g-4 justify-content-center">

            <style>
                .client-logo-wrapper {
                    height: 100px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                    background-color: #fff;
                    border-radius: 8px;
                }

                .client-logo {
                    max-height: 100%;
                    width: 450px;
                }
            </style>

            <?php
            $directory = 'assets/image/client/';
            $clientImages = [];
            for ($i = 2; $i <= 10; $i++) {
                $imagePng = $directory . 'Picture' . $i . '.png';
                $imageJpg = $directory . 'Picture' . $i . '.jpg';

                if (file_exists($imagePng)) {
                    $clientImages[] = $imagePng;
                } elseif (file_exists($imageJpg)) {
                    $clientImages[] = $imageJpg;
                } else {
                    echo "File missing: Picture" . $i . ".png or Picture" . $i . ".jpg<br>";
                }
            }
            ?>

            <?php foreach ($clientImages as $image): ?>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="p-3 text-center client-logo-wrapper">
                        <img src="<?php echo $image; ?>" alt="Client Logo" class="client-logo">
                    </div>
                </div>
            <?php endforeach; ?>

        </div>

        <div class="row mt-5">
            <div class="col-lg-8 mx-auto">
                <div class="card border-0 shadow-sm">
                    <div class="card-body p-5 text-center">
                        <i class="bi bi-quote fs-1 text-primary-custom mb-3"></i>
                        <p class="lead mb-4">"Established the company in July 2008 with an initial workforce of two engineers, total of twenty installers, helpers and laborers. Today, after thirteen years of dedicated hard work, discipline, and building long-term relationship with valuable and satisfied clients, our company has grown to more than 300 capable workmen from all areas of expertise."</p>
                        <div>
                            <h5 class="fw-bold mb-0">Mr. Rommel Perez Diaz</h5>
                            <p class="text-muted mb-0">General Manager</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<script>
    function enableSubmitButton() {
        document.getElementById('sendMessageButton').disabled = false
    }
</script>
<?php if (isset($_SESSION['user_id'])): ?>


    <section id="feedback">
        <div class="form-container">
            <h2>Feedback Form</h2>
            <div id="messagefeedback"></div>
            <form id="feedbackForm">
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <div class="input-group">
                        <span style="height: 50px;" class="input-group-text bg-white">
                            <i class="bi bi-person text-primary"></i>
                        </span>
                        <input type="text" class="form-control" id="name" value="<?= $_SESSION['name'] ?>" name="name" placeholder="Enter your name" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email Address</label>
                    <div class="input-group">
                        <span style="height: 50px;" class="input-group-text bg-white">
                            <i class="bi bi-envelope text-primary"></i>
                        </span>
                        <input type="email" class="form-control" id="email" value="<?= $_SESSION['email'] ?>" name="email" placeholder="Enter your email" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Share your experience in scaling</label>
                    <div class="star-rating" id="starRating">
                        <i class="bi bi-star" data-rating="1"></i>
                        <i class="bi bi-star" data-rating="2"></i>
                        <i class="bi bi-star" data-rating="3"></i>
                        <i class="bi bi-star" data-rating="4"></i>
                        <i class="bi bi-star" data-rating="5"></i>
                    </div>
                    <input type="hidden" name="rating" id="ratingInput" value="0">
                </div>

                <div class="mb-4">
                    <label for="comments" class="form-label">Add your comments</label>
                    <textarea class="form-control" id="comments" name="comments" placeholder="Add your comments..."></textarea>
                </div>

                <div class="text-end">
                    <button type="button" class="btn btn-cancel me-2" id="cancelBtn">Cancel</button>
                    <button type="submit" class="btn btn-submit">SUBMIT</button>
                </div>
            </form>
        </div>
    </section>

<?php endif; ?>

<?php

function getOverallStats($db)
{
    $sql = "SELECT 
                AVG(rating) AS average_rating,
                COUNT(*) AS total_reviews,
                SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) AS five_star,
                SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) AS four_star,
                SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) AS three_star,
                SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) AS two_star,
                SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) AS one_star
            FROM ratings
            WHERE status = 'Approve'";

    $stmt = $db->conn()->prepare($sql);

    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return $result;
}


function getRatingPercentages($db)
{
    $sql = "SELECT 
                stars,
                count,
                percentage
            FROM (
                SELECT 
                    '5' AS stars,
                    COUNT(*) AS count,
                    ROUND((COUNT(*) / (SELECT COUNT(*) FROM ratings WHERE status = 'Approve')) * 100, 1) AS percentage
                FROM ratings
                WHERE rating = 5 AND status = 'Approve'
                UNION
                SELECT 
                    '4' AS stars,
                    COUNT(*) AS count,
                    ROUND((COUNT(*) / (SELECT COUNT(*) FROM ratings WHERE status = 'Approve')) * 100, 1) AS percentage
                FROM ratings
                WHERE rating = 4 AND status = 'Approve'
                UNION
                SELECT 
                    '3' AS stars,
                    COUNT(*) AS count,
                    ROUND((COUNT(*) / (SELECT COUNT(*) FROM ratings WHERE status = 'Approve')) * 100, 1) AS percentage
                FROM ratings
                WHERE rating = 3 AND status = 'Approve'
                UNION
                SELECT 
                    '2' AS stars,
                    COUNT(*) AS count,
                    ROUND((COUNT(*) / (SELECT COUNT(*) FROM ratings WHERE status = 'Approve')) * 100, 1) AS percentage
                FROM ratings
                WHERE rating = 2 AND status = 'Approve'
                UNION
                SELECT 
                    '1' AS stars,
                    COUNT(*) AS count,
                    ROUND((COUNT(*) / (SELECT COUNT(*) FROM ratings WHERE status = 'Approve')) * 100, 1) AS percentage
                FROM ratings
                WHERE rating = 1 AND status = 'Approve'
            ) AS ratings
            ORDER BY stars DESC";

    $stmt = $db->conn()->prepare($sql);

    $stmt->execute();

    $percentages = [];

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $percentages[$row['stars']] = [
            'count' => $row['count'],
            'percentage' => $row['percentage']
        ];
    }

    return $percentages;
}

function getRecentFeedback($db, $limit = 4)
{
    $sql = "SELECT 
               *, DATE_FORMAT(created_at, '%M %d, %Y') AS formatted_date
            FROM ratings
            WHERE status = 'Approve'  
            ORDER BY created_at DESC
            LIMIT :limit";

    $stmt = $db->conn()->prepare($sql);

    $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);

    $stmt->execute();

    $feedbacks = [];

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $feedbacks[] = $row;
    }

    return $feedbacks;
}


$stats = getOverallStats($db);
$percentages = getRatingPercentages($db);
$recentFeedbacks = getRecentFeedback($db);

?>


<section class="ratings-section">
    <div class="container ratings-container">
        <div class="section-header">
            <h2 class="section-title">Customer Feedback</h2>
            <p class="section-subtitle text-center">See what our clients have to say about their experience with our scaling services</p>
        </div>

        <div class="row">
            <div class="col-lg-5 mb-4">
                <div class="stats-card">
                    <div class="text-center mb-3">
                        <h3 class="overall-rating"><?php echo number_format($stats['average_rating'], 1); ?></h3>
                        <p class="rating-out-of">out of 5</p>
                        <div class="rating-stars">
                            <?php
                            $avgRating = $stats['average_rating'];
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= floor($avgRating)) {
                                    echo '<i class="bi bi-star-fill"></i>';
                                } elseif ($i - 0.5 <= $avgRating) {
                                    echo '<i class="bi bi-star-half"></i>';
                                } else {
                                    echo '<i class="bi bi-star"></i>';
                                }
                            }
                            ?>
                        </div>
                        <p class="mb-0">Based on <?php echo $stats['total_reviews']; ?> reviews</p>
                    </div>

                    <div class="stats-info mt-4">
                        <div class="stats-item">
                            <p class="stats-number"><?php echo isset($percentages['5']) ? $percentages['5']['percentage'] . '%' : '0%'; ?></p>
                            <p class="stats-label">5 Stars</p>
                        </div>
                        <div class="stats-item">
                            <p class="stats-number"><?php echo isset($percentages['4']) ? $percentages['4']['percentage'] . '%' : '0%'; ?></p>
                            <p class="stats-label">4 Stars</p>
                        </div>
                        <div class="stats-item">
                            <p class="stats-number"><?php echo isset($percentages['3']) ? $percentages['3']['percentage'] . '%' : '0%'; ?></p>
                            <p class="stats-label">3 Stars</p>
                        </div>
                        <div class="stats-item">
                            <p class="stats-number"><?php echo (isset($percentages['2']) ? $percentages['2']['percentage'] : 0) +
                                                        (isset($percentages['1']) ? $percentages['1']['percentage'] : 0) . '%'; ?></p>
                            <p class="stats-label">1-2 Stars</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 mb-4">
                <?php
                for ($i = 5; $i >= 1; $i--) {
                    $percentage = isset($percentages[$i]) ? $percentages[$i]['percentage'] : 0;
                    $colorClass = "";

                    if ($i == 5) $colorClass = "bg-success";
                    else if ($i == 4) $colorClass = "bg-primary";
                    else if ($i == 3) $colorClass = "bg-info";
                    else if ($i == 2) $colorClass = "bg-warning";
                    else $colorClass = "bg-danger";
                ?>
                    <div class="rating-progressbar">
                        <div class="progress-label">
                            <span class="progress-star"><?php echo $i; ?> <i class="bi bi-star-fill"></i></span>
                            <span class="progress-percentage"><?php echo $percentage; ?>%</span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar <?php echo $colorClass; ?>" role="progressbar" style="width: <?php echo $percentage; ?>%" aria-valuenow="<?php echo $percentage; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>

        <h3 class="mb-4">Recent Feedback</h3>
        <div class="row">
            <?php if (!empty($recentFeedbacks)): ?>
                <?php foreach ($recentFeedbacks as $feedback) { ?>
                    <div class="col-md-6 mb-4">
                        <div class="testimonial-card">
                            <div class="testimonial-header">
                                <div class="testimonial-avatar">
                                    <i class="bi bi-person"></i>
                                </div>
                                <div class="testimonial-info">
                                    <h5><?php echo htmlspecialchars($feedback['name']); ?></h5>
                                    <p class="testimonial-date"><?php echo $feedback['formatted_date']; ?></p>
                                </div>
                                <div class="testimonial-rating">
                                    <?php
                                    for ($i = 1; $i <= 5; $i++) {
                                        if ($i <= $feedback['rating']) {
                                            echo '<i class="bi bi-star-fill"></i>';
                                        } else {
                                            echo '<i class="bi bi-star"></i>';
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                            <p class="testimonial-content"><?php echo htmlspecialchars($feedback['comments']); ?></p>
                        </div>
                    </div>
                <?php } ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <p class="text-muted">No feedback available at the moment.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php if (isset($_SESSION['user_id'])): ?>

    <div id="chat-float-btn" class="position-fixed bottom-0 end-0 m-4">
        <button class="btn btn-primary rounded-circle p-3 shadow" id="startChat">
            💬
        </button>
    </div>

    <div id="chatBox" class="position-fixed bottom-0 end-0 m-4 card shadow d-none" style="width: 320px; height: 480px;">
        <div class="card-header d-flex justify-content-between align-items-center">
            <strong>Chat with Admin</strong>
            <button type="button" class="btn-close btn-sm" id="closeChat"></button>
        </div>
        <div style="overflow: auto;" class="card-body" id="chat-box">
            <!-- Chat messages will appear here -->
        </div>

        <!-- Preview area for attachments -->
        <div id="attachment-preview" class="px-3 pb-2 d-none">
            <div class="card">
                <div class="card-body p-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="d-flex align-items-center">
                            <i class="bi bi-paperclip me-2"></i>
                            <span id="file-name" class="text-truncate" style="max-width: 200px;"></span>
                        </div>
                        <button type="button" class="btn-close btn-sm" id="remove-attachment"></button>
                    </div>
                </div>
            </div>
        </div>

        <div class="card-footer p-2">
            <div class="input-group">
                <label for="attachment" class="btn btn-outline-secondary border d-flex align-items-center justify-content-center" style="width: 40px; height: 50px;">
                    <i class="bi bi-paperclip"></i>
                </label>
                <input type="file" id="attachment" class="d-none">
                <input type="text" id="message-input" class="form-control" placeholder="Type a message...">
                <button style="height: 50px;" class="btn btn-success" id="send-message-btn">Send</button>
            </div>
        </div>
    </div>

<?php endif; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        var carousels = document.querySelectorAll('.carousel');
        carousels.forEach(function(carousel) {
            new bootstrap.Carousel(carousel, {
                interval: 5000,
                wrap: true,
                touch: true
            });
        });
    });
    $(document).ready(function() {
        const $stars = $('.star-rating .bi');
        const $ratingInput = $('#ratingInput');

        $stars.mouseenter(function() {
            const rating = $(this).data('rating');
            resetStars();
            fillStars(rating);
        });

        $('.star-rating').mouseleave(function() {
            resetStars();
            const currentRating = parseInt($ratingInput.val());
            if (currentRating > 0) {
                fillStars(currentRating);
            }
        });

        $stars.click(function() {
            const rating = $(this).data('rating');
            $ratingInput.val(rating);
            resetStars();
            fillStars(rating);
        });

        function resetStars() {
            $stars.removeClass('bi-star-fill').addClass('bi-star');
        }

        function fillStars(rating) {
            $stars.each(function() {
                if ($(this).data('rating') <= rating) {
                    $(this).removeClass('bi-star').addClass('bi-star-fill');
                }
            });
        }

        $('#feedbackForm').submit(function(e) {
            e.preventDefault();

            const rating = $ratingInput.val();
            if (rating === '0') {
                alert('Please select a star rating before submitting.');
                return false;
            }

            $.ajax({
                url: 'actions/insert-feedback.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#messagefeedback').html("<div class='alert alert-success'>" + response.message + "</div>").hide().fadeIn('slow');

                        setTimeout(function() {
                            $('#messagefeedback').fadeOut('slow', function() {
                                $(this).html('').show();
                                $('#feedbackForm')[0].reset();
                                resetStars();
                                $ratingInput.val('0');
                            });
                        }, 1500);
                    }
                }
            });
        });


        $('#cancelBtn').click(function() {
            $('#feedbackForm')[0].reset();
            resetStars();
            $ratingInput.val('0');
        });
    });
</script>

<script src="https://js.pusher.com/8.4.0/pusher.min.js"></script>

<?php if (isset($_SESSION['user_id'])): ?>


    <script>
        Pusher.logToConsole = false;
        var pusher = new Pusher('<?= $_ENV['PUSHER_APP_KEY'] ?>', {
            cluster: '<?= $_ENV['PUSHER_APP_CLUSTER'] ?>'
        });

        const escapeHtml = (unsafe) => {
            return unsafe
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/\n/g, "<br>");
        };

        let conversationId = '';

        let isRequestInProgress = false;

        function fetchConversationId() {
            if (isRequestInProgress) return;

            isRequestInProgress = true;

            $.ajax({
                url: '<?= BASE_URL ?>/actions/fetch.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    conversationId = response.conversation_id;
                },
                complete: function() {
                    isRequestInProgress = false;
                }
            });
        }

        $(document).ready(function() {
            setInterval(function() {
                fetchConversationId();
            }, 1500);
        });

        $(document).ready(function() {
            setInterval(() => {
                loadMessage(conversationId)
            }, 1000);
        });

        function loadMessage(conversationId) {
            $.ajax({
                url: '<?= BASE_URL ?>/actions/fetch_messages.php',
                type: 'GET',
                data: {
                    conversation_id: conversationId
                },
                dataType: 'json',
                success: function(response) {
                    console.log(response);

                    if (response.status === 'success') {
                        const messages = response.messages;
                        const currentUserId = '<?= $currentUserId ?>';

                        if (messages.length === 0) {
                            $('#chat-box').html('<div class="text-center text-muted p-3">Welcome to drytec! Start sending message to admin.</div>');
                            return;
                        }

                        const messageHtml = messages.map((message) => {
                            const isSender = message.sender_id == currentUserId;
                            const alignment = isSender ? 'text-end' : 'text-start';
                            const bubbleClass = isSender ? 'bg-primary text-white' : 'bg-light';
                            const date = new Date(message.created_at);
                            const formattedTime = date.toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit'
                            });

                            let messageContent = `
                    <div class="${alignment} mb-2">
                        <div class="d-inline-block ${bubbleClass} rounded p-2" style="max-width: 80%;">`;
                            if (message.message && message.message.trim() !== '') {
                                messageContent += `<span>${escapeHtml(message.message)}</span>`;
                            }

                            if (message.attachment_path) {
                                const fileExt = message.attachment_name.split('.').pop().toLowerCase();
                                let fileIcon = 'bi-file';
                                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'].includes(fileExt)) {
                                    fileIcon = 'bi-file-image';
                                } else if (['doc', 'docx'].includes(fileExt)) {
                                    fileIcon = 'bi-file-word';
                                } else if (['xls', 'xlsx', 'csv'].includes(fileExt)) {
                                    fileIcon = 'bi-file-excel';
                                } else if (['pdf'].includes(fileExt)) {
                                    fileIcon = 'bi-file-pdf';
                                } else if (['zip', 'rar', '7z'].includes(fileExt)) {
                                    fileIcon = 'bi-file-zip';
                                }

                                const baseUrl = '<?= BASE_URL ?>/assets/' + message.attachment_path;

                                messageContent += `
                        <div class="mt-2">
                            <a href="${baseUrl}" target="_blank" class="d-flex align-items-center text-decoration-none ${isSender ? 'text-white' : 'text-primary'}">
                                <i class="bi ${fileIcon} me-2"></i>
                                <span class="text-truncate" style="max-width: 150px;">${escapeHtml(message.attachment_name)}</span>
                            </a>
                        </div>`;
                            }

                            messageContent += `
                        </div>
                        <small class="text-muted d-block">${formattedTime}</small>
                    </div>`;

                            return messageContent;
                        }).join('');

                        $('#chat-box').html(messageHtml);
                        $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Failed to load messages: ' + error);
                    $('#chat-box').html('<div class="text-center text-danger p-3">Failed to load messages</div>');
                }
            });
        }

        var channel = pusher.subscribe('conversation.' + conversationId);


        channel.bind('message.sent', function(data) {
            const currentUserId = '<?= $currentUserId ?>';
            const isSender = data.sender_id == currentUserId;
            const alignment = isSender ? 'text-end' : 'text-start';
            const bubbleClass = isSender ? 'bg-primary text-white' : 'bg-light';

            // Start building the message HTML
            let messageHTML = `
        <div class="${alignment} mb-2">
            <div class="d-inline-block ${bubbleClass} rounded p-2" style="max-width: 80%;">`;

            // Add message text if not empty
            if (data.message && data.message.trim() !== '') {
                messageHTML += `<span>${escapeHtml(data.message)}</span>`;
            }

            // Add attachment if exists
            if (data.attachment_url) {
                // Get file extension to determine icon
                const fileName = data.attachment_name || 'attachment';
                const fileExt = fileName.split('.').pop().toLowerCase();
                let fileIcon = 'bi-file';

                // Customize icon based on file type
                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg'].includes(fileExt)) {
                    fileIcon = 'bi-file-image';
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon = 'bi-file-word';
                } else if (['xls', 'xlsx', 'csv'].includes(fileExt)) {
                    fileIcon = 'bi-file-excel';
                } else if (['pdf'].includes(fileExt)) {
                    fileIcon = 'bi-file-pdf';
                } else if (['zip', 'rar', '7z'].includes(fileExt)) {
                    fileIcon = 'bi-file-zip';
                }

                // Create attachment display
                messageHTML += `
        <div class="mt-2">
            <a href="${data.attachment_url}" target="_blank" class="d-flex align-items-center text-decoration-none ${isSender ? 'text-white' : 'text-primary'}">
                <i class="bi ${fileIcon} me-2"></i>
                <span class="text-truncate" style="max-width: 150px;">${escapeHtml(fileName)}</span>
            </a>
        </div>`;
            }

            // Close the message container and add timestamp
            messageHTML += `
            </div>
            <small class="text-muted d-block">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</small>
        </div>`;

            $('#chat-box').append(messageHTML);
            $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
        });



        let selectedFile = null;

        $('#attachment').change(function(e) {
            const file = e.target.files[0];
            if (file) {
                selectedFile = file;
                $('#file-name').text(file.name);
                $('#attachment-preview').removeClass('d-none');
            }
        });

        // Remove attachment
        $('#remove-attachment').click(function() {
            selectedFile = null;
            $('#attachment').val('');
            $('#attachment-preview').addClass('d-none');
        });

        // Send message
        $('#send-message-btn').click(function() {
            var messageText = $('#message-input').val();

            if (messageText.trim() !== '' || selectedFile) {
                // Create FormData to handle file uploads
                const formData = new FormData();
                formData.append('conversation_id', conversationId);
                formData.append('sender_id', '<?= $currentUserId ?>');
                formData.append('message', messageText);

                if (selectedFile) {
                    formData.append('attachment', selectedFile);
                }

                $.ajax({
                    url: '<?= BASE_URL ?>/actions/send_message.php',
                    type: 'POST',
                    data: formData,
                    processData: false, // Don't process the data
                    contentType: false, // Don't set content type
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);
                        $('#message-input').val('');

                        if (selectedFile) {
                            selectedFile = null;
                            $('#attachment').val('');
                            $('#attachment-preview').addClass('d-none');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Message send failed: ' + error);
                    }
                });
            }
        });

        // Allow sending message with Enter key
        $('#message-input').keypress(function(e) {
            if (e.which === 13) { // Enter key
                $('#send-message-btn').click();
                return false;
            }
        })
    </script>



<?php endif; ?>

<script>
    $(document).ready(function() {
        let loginRequest;

        $('#loginForm').submit(function(e) {
            e.preventDefault();

            const loginBtn = $('#loginBtn');
            loginBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Logging in...');

            if (loginRequest && loginRequest.readyState !== 4) {
                loginRequest.abort();
            }

            $('#loginForm .is-invalid').removeClass('is-invalid');
            $('#loginForm .invalid-feedback').remove();

            loginRequest = $.ajax({
                url: "<?= BASE_URL ?>/actions/login.php",
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                timeout: 1500000,
                success: function(response) {
                    if (!response.success) {
                        if (response.errors) {
                            Object.keys(response.errors).forEach(function(field) {
                                const input = $('#loginForm').find(`[name="${field}"]`);
                                input.addClass('is-invalid');

                                if (input.next('.invalid-feedback').length === 0) {
                                    input.after(`<div class="invalid-feedback">${response.errors[field]}</div>`);
                                }
                            });
                        }
                        loginBtn.prop('disabled', false).html('Login');
                    } else {
                        location.reload();
                    }
                },
                error: function(xhr, status) {
                    if (status !== 'abort') {
                        alert('Login request failed or timed out. Please try again.');
                        loginBtn.prop('disabled', false).html('Login');
                    }
                }
            });
        });


        $('#registerForm').submit(function(e) {
            e.preventDefault()

            $('#regBtn').prop("disabled", true)
            $('#regBtn').html("Please Wait...")

            $.ajax({
                url: "<?= BASE_URL ?>/actions/register.php",
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(response) {
                    console.log(response);

                    $('#registerForm .form-control').removeClass('is-invalid');
                    $('#registerForm .invalid-feedback').remove();

                    if (!response.success) {
                        if (response.errors) {
                            Object.keys(response.errors).forEach(function(field) {
                                const input = $('#registerForm').find(`[name="${field}"]`);
                                input.addClass('is-invalid');

                                if (input.next('.invalid-feedback').length === 0) {
                                    input.after(`<div class="invalid-feedback">${response.errors[field]}</div>`);
                                }
                            });
                        }

                        $('#regBtn').prop("disabled", false)
                        $('#regBtn').html("Create Account")
                    } else {
                        $('#message_reg').html("<div class='alert alert-success'>" + response.message + "</div>")
                        $('#regBtn').prop("disabled", false)
                        $('#regBtn').html("Create Account")
                        $('#registerForm .form-control').removeClass('is-valid');
                        $('#registerForm')[0].reset();
                        setTimeout(() => {
                            $('#loginOrRegisterModal').modal('hide')
                            $('#loginModal').modal('show')
                        }, 1500);

                    }
                }
            })
        })
    });
</script>

<script>
    $(document).ready(function() {
        $('#contactUsForm').submit(function(e) {
            e.preventDefault();

            let isValid = true;

            $('#contactUsForm .form-control').removeClass('is-invalid');
            $('#messagecontact').html("");

            $('#contactUsForm .form-control').each(function() {
                const $input = $(this);
                const fieldName = $input.attr('name');

                // Format field name (e.g., full_name → Full name)
                const formattedName = fieldName
                    .replace(/_/g, ' ')
                    .replace(/\b\w/g, l => l.toUpperCase());

                $input.removeClass('is-invalid');
                $input.next('.invalid-feedback').remove();

                if (!$input.val().trim()) {
                    $input.addClass('is-invalid');
                    isValid = false;
                    $input.after(`<div class="invalid-feedback">Please enter ${formattedName.toLowerCase()}.</div>`);
                }
            });



            if (isValid) {
                const $button = $('#contactUsForm button[type="submit"]');
                $button.prop('disabled', true);
                $button.html(`<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Sending...`);

                var formData = new FormData(this);

                $.ajax({
                    url: 'actions/contact-us.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);

                        if (response.status) {
                            setTimeout(() => {
                                $('#messagecontact')
                                    .html(`<div class="alert alert-success">` + response.message + `</div>`)
                                    .children('.alert')
                                    .delay(3000)
                                    .fadeOut(1000, function() {
                                        $(this).remove();
                                    });

                                $('#contactUsForm')[0].reset();
                                $('#contactUsForm .form-control').removeClass('is-invalid');
                                $button.prop('disabled', false);
                                $button.html('Send Message');

                                setTimeout(() => {
                                    location.reload();
                                }, 1500);
                            }, 1500);
                        } else {
                            $('#messagecontact')
                                .html(`<div class="alert alert-danger">${response.message}</div>`)
                                .children('.alert')
                                .delay(3000)
                                .fadeOut(1000, function() {
                                    $(this).remove();
                                });

                            $button.prop('disabled', false);
                            $button.html('Send Message');
                        }
                    },
                    error: function() {
                        $('#messagecontact')
                            .html(`<div class="alert alert-danger">An error occurred. Please try again later.</div>`)
                            .children('.alert')
                            .delay(3000)
                            .fadeOut(1000, function() {
                                $(this).remove();
                            });

                        $button.prop('disabled', false);
                        $button.html('Send Message');
                    }
                });

            }
        });
    });

    $(document).ready(function() {
        $('#startChat').click(function() {
            $('#chatBox').removeClass('d-none');
            $('#namePrompt').removeClass('d-none');
            $('#chatWindow').addClass('d-none');
        });

        $('#closeChat').click(function() {
            $('#chatBox').addClass('d-none');
        });

    });


    document.querySelectorAll('.restrict-text').forEach(input => {
        input.addEventListener('input', () => {
            input.value = input.value.replace(/[^A-Za-z\s]/g, '');
        });
    });

    document.querySelectorAll('#registerForm input').forEach(input => {
        input.addEventListener('input', () => {
            if (input.value.trim() !== '') {
                input.classList.add('is-valid');
                input.classList.remove('is-invalid');
            } else {
                input.classList.remove('is-valid');
            }
        });
    });
</script>


<?php include __DIR__ . '/../partials/footer.php'; ?>
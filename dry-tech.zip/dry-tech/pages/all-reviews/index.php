<?php

include __DIR__ . '/../partials/header.php';

$itemsPerPage = 10;

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $itemsPerPage;

$totalStmt = $db->conn()->prepare("SELECT COUNT(*) FROM ratings f");
$totalStmt->execute();
$totalRecords = $totalStmt->fetchColumn();

$stmt = $db->conn()->prepare("SELECT *, DATE_FORMAT(f.created_at, '%M %d, %Y') AS formatted_date FROM ratings f ORDER BY f.created_at DESC LIMIT :offset, :limit");
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $itemsPerPage, PDO::PARAM_INT);
$stmt->execute();
$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalPages = ceil($totalRecords / $itemsPerPage);

?>

<div class="container py-5 mt-5">
    <h2 class="text-center mb-4">Customer Reviews</h2>

    <?php if (count($feedbacks) > 0): ?>
        <div class="row g-4">
            <?php foreach ($feedbacks as $feedback): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card shadow-sm border-light rounded-3 d-flex flex-column" style="height: 100%">
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex justify-content-between mb-3">
                                <strong class="h5"><?php echo htmlspecialchars($feedback['name']); ?></strong>
                                <small class="text-muted"><?php echo htmlspecialchars($feedback['formatted_date']); ?></small>
                            </div>
                            <div class="mb-3">
                                <span class="text-warning">
                                    <?php echo str_repeat('★', $feedback['rating']); ?>
                                    <?php echo str_repeat('☆', 5 - $feedback['rating']); ?>
                                </span>
                            </div>
                            <p class="card-text flex-grow-1"><?php echo nl2br(htmlspecialchars($feedback['comments'])); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="text-center text-muted">No reviews found.</p>
    <?php endif; ?>

    <!-- Pagination -->
    <div class="d-flex justify-content-center mt-4">
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <li class="page-item <?php echo ($page == 1) ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo max(1, $page - 1); ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>

                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <li class="page-item <?php echo ($page == $totalPages) ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo min($totalPages, $page + 1); ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<?php include __DIR__ . '/../partials/footer.php'; ?>
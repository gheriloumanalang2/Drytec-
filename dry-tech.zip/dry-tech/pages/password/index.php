<?php

use App\Class\Session;

if (Session::has('user_id')) {
    header("location: dashboard");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drytec Construction Services - Forgot Password</title>
    <!-- Bootstrap 5 CSS -->
    <link href="<?= BASE_URL ?>/assets/css/bootstrap.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/login.css">
</head>

<body>
    <div class="login-container">
        <div class="login-card bg-white">
            <div class="login-header">
                <h1 class="mb-4"><span class="text-primary-custom">DRY</span>TEC</h1>
            </div>
            <div class="card-body p-4 p-md-5">
                <h4 class="fw-bold mb-4 text-center">Enter your email to proceed</h4>
                <?php if (isset($_SESSION['error'])): ?>
                    <div class="custom-alert error-alert">
                        <strong>Oops!</strong> <?= $_SESSION['error']; ?>
                        <?php unset($_SESSION['error']); ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['success'])): ?>
                    <div class="custom-alert-success success-alert">
                        <strong>Hi! </strong> <?= $_SESSION['success']; ?>
                        <?php unset($_SESSION['success']); ?>
                    </div>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>/actions/send-email.php" method="POST">
                    <div class="mb-4">
                        <label for="email" class="form-label">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bi bi-envelope"></i>
                            </span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" required>
                        </div>
                    </div>

                    <div class="d-grid mb-4">
                        <button type="submit" class="btn btn-primary-custom btn-lg py-3">Reset Password</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="position-fixed bottom-0 start-50 translate-middle-x mb-4">
            <a href="login" class="text-dark text-decoration-none">
                <i class="bi bi-arrow-left me-2"></i>Back to Home
            </a>
        </div>
    </div>

    <script src="assets/js/bootstrap.js"></script>
</body>

</html>
<?php

use App\Class\Session;

if (Session::has('user_id')) {
    header("location: ../dashboard");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drytec Construction Services - Reset Password</title>
    <!-- Bootstrap 5 CSS -->
    <link href="<?= BASE_URL ?>/assets/css/bootstrap.css" rel="stylesheet">
    <script src="<?= BASE_URL ?>/assets/js/jquery.js"></script>
    <script src="<?= BASE_URL ?>/assets/js/bootstrap.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/login.css">
</head>

<body>
    <div class="login-container">
        <div class="login-card bg-white">
            <div class="login-header">
                <h1 class="mb-4"><span class="text-primary-custom">DRY</span>TEC</h1>
            </div>
            <div class="card-body p-4 p-md-5">
                <h4 class="fw-bold mb-4 text-center">Enter your new password</h4>
                <?php if (Session::has('error')): ?>
                    <div class="custom-alert error-alert">
                        <strong>Oops!</strong> <?= Session::get('error'); ?>
                        <?php Session::remove('error'); ?>
                    </div>
                <?php endif; ?>

                <?php if (Session::has('success')): ?>
                    <div class="custom-alert-success success-alert">
                        <strong>Hi! </strong> <?= Session::get('success'); ?>
                        <?php Session::remove('success'); ?>
                    </div>
                <?php endif; ?>

                <form action="<?= BASE_URL ?>/actions/verify.php" method="POST">

                    <div class="mb-4">
                        <input type="hidden" name="token" value="<?= $_GET['token'];  ?>">
                        <label for="new_password" class="form-label">New Password</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bi bi-lock"></i>
                            </span>
                            <input type="password" class="form-control" name="new_password" id="new_password" required>
                            <button class="btn btn-outline-secondary" type="button" id="toggleNewPassword">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="password_confirmation" class="form-label">Confirm Password</label>
                        <div class="input-group">
                            <span class="input-group-text">
                                <i class="bi bi-lock"></i>
                            </span>
                            <input type="password" class="form-control" name="password_confirmation" id="confirm_password" required>
                            <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                <i class="bi bi-eye"></i>
                            </button>
                        </div>
                    </div>

                    <div class="d-grid mb-4">
                        <button type="submit" class="btn btn-primary-custom btn-lg py-3">Change Password</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="position-fixed bottom-0 start-50 translate-middle-x mb-4">
            <a href="../login" class="text-dark text-decoration-none">
                <i class="bi bi-arrow-left me-2"></i>Back to Login
            </a>
        </div>
    </div>

    <script>
        function setupToggle(buttonId, inputId) {
            const toggleBtn = document.getElementById(buttonId);
            const input = document.getElementById(inputId);

            toggleBtn.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.classList.remove('bi-eye');
                    icon.classList.add('bi-eye-slash');
                } else {
                    input.type = 'password';
                    icon.classList.remove('bi-eye-slash');
                    icon.classList.add('bi-eye');
                }
            });
        }

        setupToggle('toggleNewPassword', 'new_password');
        setupToggle('toggleConfirmPassword', 'confirm_password');
    </script>

</body>

</html>
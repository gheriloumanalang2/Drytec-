<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 Not Found</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }

        .error-wrapper {
            max-width: 600px;
            margin: 100px auto;
            text-align: center;
        }

        .error-code {
            font-size: 120px;
            font-weight: bold;
            color: #dc3545;
        }

        .error-message {
            font-size: 24px;
            margin-top: 20px;
        }

        .error-description {
            margin-top: 10px;
            color: #6c757d;
        }

        .btn-home {
            margin-top: 30px;
            padding: 10px 25px;
            font-size: 18px;
            background-color: #007bff;
            color: white;
            border: none;
        }

        .btn-home:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>

    <div class="error-wrapper">
        <div class="error-code">404</div>
        <div class="error-message">Oops! Page Not Found</div>
        <div class="error-description mb-5">The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</div>
        <a href="home" class="btn btn-primary">Go to Homepage</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <h4 class="fw-bold mb-4"><span class="text-primary-custom">DRY</span>TEC</h4>
                <p class="mb-4">At Drytec Construction Services, we strive to meet the changing needs of our clients with quality services delivered by experienced and dedicated professionals.</p>
            </div>

            <div class="col-md-4 col-lg-2">
                <h5 class="fw-bold mb-4">Our Services</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none">Engineering</a></li>
                    <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none">Project Contracts</a></li>
                    <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none">Procurement</a></li>
                    <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none">Commissioning</a></li>
                    <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none">Safety & Environment</a></li>
                    <li class="mb-2"><a href="#" class="text-white-50 text-decoration-none">Quality Assurance</a></li>
                </ul>
            </div>
        </div>
        <hr class="my-4 bg-secondary">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-md-0 text-white-50">&copy; <?= date("Y") ?> Drytec Construction Services. All Rights Reserved.</p>
            </div>
            <!-- <div class="col-md-6 text-center text-md-end">
                <p class="mb-0 text-white-50">Design by <a href="#" class="text-white-50">YourCompany</a></p>
            </div> -->
        </div>
    </div>
</footer>

</body>

</html>
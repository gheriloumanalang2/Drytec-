<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DryTech Construction Services - Homepage</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/chat.css">
    <!-- icon sa taas -->
    <link rel="icon" type="image/x-icon" href="<?= BASE_URL ?>/assets/image/favicon.ico">
    <!-- end icon -->

    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/modal.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="<?= BASE_URL ?>/assets/js/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/rating.css">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <style>
        .mobile-nav-sidebar {
            position: fixed;
            top: 0;
            left: -100%;
            width: 75%;
            height: 100%;
            z-index: 1050;
            overflow-y: auto;
            transition: left 0.3s ease-in-out;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.5);
        }

        .mobile-nav-sidebar.show {
            left: 0;
        }

        .mobile-nav-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 1040;
            display: none;
        }

        .mobile-nav-backdrop.show {
            display: block;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <img style="width: 50px; height: 30px; border-radius: 20px;" src="<?= BASE_URL ?>/assets/image/logo.jpg"> <span class="text-primary-custom">DRY</span>TEC
            </a>
            <button class="navbar-toggler" type="button" onclick="toggleMobileNav()">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse d-none d-lg-block" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <!-- <a class="nav-link" href="?page=login">Home</a> -->
                        <a class="nav-link text-white" href="<?= BASE_URL ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#services">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#projects">Projects</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#clients">Clients</a>
                    </li>
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <li>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal">
                                LOGIN NOW
                            </button>
                        </li>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item">
                            <button type="button" class="nav-link btn btn-primary text-white" data-bs-toggle="modal" data-bs-target="#contactModal">
                                Contact Us
                            </button>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#feedback">Feedback</a>
                        </li>
                        <form id="logoutForm" action="logout" method="POST" style="display: none;">
                        </form>

                        <li class="nav-item">
                            <button class="nav-link text-white btn btn-danger btn-sm"
                                onclick="if(confirm('Are you sure you want to logout?')) document.getElementById('logoutForm').submit();">
                                Logout
                            </button>
                        </li>


                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </nav>

    <!-- Slide-in Mobile Nav Sidebar -->
    <div id="mobileNavSidebar" class="mobile-nav-sidebar bg-dark text-white">
        <div class="p-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold">Menu</h5>
            <button class="btn-close btn-close-white" onclick="toggleMobileNav()"></button>
        </div>
        <div class="p-3 d-flex flex-column text-center">
            <a class="nav-link my-2 text-white fs-5" href="#home">Home</a>
            <a class="nav-link my-2 text-white fs-5" href="#about">About</a>
            <a class="nav-link my-2 text-white fs-5" href="#services">Services</a>
            <a class="nav-link my-2 text-white fs-5" href="#projects">Projects</a>
            <a class="nav-link my-2 text-white fs-5" href="#clients">Clients</a>
            <?php if (!isset($_SESSION['user_id'])): ?>

                <a class="nav-link my-2 text-white fs-5" href="#">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#loginModal">
                        LOGIN NOW
                    </button>
                </a>
            <?php endif; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <button type="button" class="nav-link btn btn-primary text-white" data-bs-toggle="modal" data-bs-target="#contactModal">
                    Contact Us
                </button>
                <a class="nav-link my-2 text-white fs-5" href="#feedback">Feedback</a>
                <button class="btn btn-danger mt-3"
                    onclick="if(confirm('Are you sure you want to logout?')) document.getElementById('logoutForm').submit();">
                    Logout
                </button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Backdrop -->
    <div id="mobileNavBackdrop" class="mobile-nav-backdrop" onclick="toggleMobileNav()"></div>

    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="loginModalLabel">DryTec</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="loginForm" autocomplete="off">
                    <div class="modal-body">
                        <p class="mb-3 text-center">Login to your account.</p>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter email">
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Enter password">
                        </div>

                        <div class="mb-3 justify-content-end d-flex">
                            <a href="reset-password" class="btn-link">Forgot Password?</a>
                        </div>
                    </div>

                    <div class="modal-footer justify-content-between">
                        <button type="submit" id="loginBtn" class="btn btn-primary w-100">Login</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="contactModal" tabindex="-1" aria-labelledby="contactModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="contactModalLabel">Get In Touch With Us</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <!-- Contact info -->
                            <div class="col-lg-5 mb-4">
                                <div class="card border-0 shadow-sm p-4 h-100">
                                    <div class="card-body">
                                        <h4 class="fw-bold mb-4">Our Contact Information</h4>
                                        <div class="d-flex align-items-center mb-4">
                                            <div class="bg-light p-3 rounded-circle me-3">
                                                <i class="bi bi-geo-alt text-primary-custom fs-4"></i>
                                            </div>
                                            <div>
                                                <h5 class="fw-bold mb-1">Our Location</h5>
                                                <p class="mb-0">Unit 2810 Lancaster Hotel Shaw Blvd. Mandaluyong City</p>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-4">
                                            <div class="bg-light p-3 rounded-circle me-3">
                                                <i class="bi bi-envelope text-primary-custom fs-4"></i>
                                            </div>
                                            <div>
                                                <h5 class="fw-bold mb-1">Email Us</h5>
                                                <p class="mb-0">drytec.construction@yahoo.com.ph</p>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-4">
                                            <div class="bg-light p-3 rounded-circle me-3">
                                                <i class="bi bi-telephone text-primary-custom fs-4"></i>
                                            </div>
                                            <div>
                                                <h5 class="fw-bold mb-1">Call Us</h5>
                                                <p class="mb-0">8-532-1818 local 2810</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="card border-0 shadow-sm mb-4">
                                    <div class="card-body p-4">
                                        <h4 class="fw-bold mb-4">Send us a message</h4>
                                        <div id="messagecontact"></div>
                                        <form id="contactUsForm">
                                            <div class="row g-3">
                                                <div class="col-md-6">
                                                    <label for="name" class="form-label">Full Name</label>
                                                    <input type="text" class="form-control" id="name" name="full_name" placeholder="John Doe">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="email" class="form-label">Email Address</label>
                                                    <input type="email" class="form-control" id="email" name="email" placeholder="john@example.com">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="phone" class="form-label">Phone Number</label>
                                                    <input type="tel" class="form-control" id="phone" name="phone" placeholder="+1 (555) 123-4567">
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="subject" class="form-label">Subject</label>
                                                    <input type="text" class="form-control" id="subject" name="subject" placeholder="Project Inquiry">
                                                </div>
                                                <div class="col-12">
                                                    <label for="address" class="form-label">Location</label>
                                                    <textarea class="form-control" id="address" name="address" rows="2"
                                                        placeholder="Location of the project."></textarea>
                                                </div>
                                                <div class="col-12">
                                                    <label for="message" class="form-label">Message</label>
                                                    <textarea class="form-control" id="message" name="message" rows="5" placeholder="How can we help you?"></textarea>
                                                </div>
                                                <div class="col-md-6">
                                                    <label for="client" class="form-label">Client</label>
                                                    <input type="text" class="form-control" id="client" name="client" placeholder="Client Name">
                                                </div>

                                                <div class="col-md-6">
                                                    <label for="contractAmount" class="form-label">Contract Amount</label>
                                                    <input type="number" class="form-control" id="contractAmount" name="contract_amount" placeholder="1000.00" step="0.01">
                                                </div>
                                                <div class="col-12">
                                                    <label for="attachment" class="form-label">
                                                        <i class="bi bi-paperclip me-1"></i> Attachment (Optional)
                                                    </label>
                                                    <input type="file" multiple class="form-control" id="attachment" name="attachment[]">
                                                    <small class="form-text text-muted">Upload related images.</small>
                                                </div>

                                                <div class="col-12">
                                                    <div class="g-recaptcha" data-sitekey="<?= $_ENV['SITE_KEY'] ?>" data-callback="enableSubmitButton"></div>
                                                </div>
                                                <div class="col-12">
                                                    <button type="submit" id="sendMessageButton" disabled class="btn btn-warning px-4 py-3 fw-bold w-100">Send Message</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                                <div class="card border-0 shadow-sm overflow-hidden">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4620.45160125392!2d121.04754967577335!3d14.58370347748876!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c83949975521%3A0xe557f8939b6b1e98!2sLancaster%20Hotel%20Manila!5e1!3m2!1sen!2sph!4v1744890270531!5m2!1sen!2sph" width="100%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>


    <script>
        function toggleMobileNav() {
            document.getElementById('mobileNavSidebar').classList.toggle('show');
            document.getElementById('mobileNavBackdrop').classList.toggle('show');
        }
    </script>
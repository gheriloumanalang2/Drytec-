<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Real-time Chat</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/chat.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

    <div class="container w-25 mt-5">
        <div class="card shadow">
            <div class="card-body" id="chat-box">
            </div>
            <div class="card-footer">
                <div class="input-group">
                    <input type="text" id="message-input" class="form-control" placeholder="Type a message...">
                    <button class="btn btn-success" id="send-message-btn">Send</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Pusher JS -->
    <script src="https://js.pusher.com/8.4.0/pusher.min.js"></script>

    <script>
        Pusher.logToConsole = false;
        var pusher = new Pusher('<?= $_ENV['PUSHER_APP_KEY'] ?>', {
            cluster: '<?= $_ENV['PUSHER_APP_CLUSTER'] ?>'
        });

        var conversationId = 1;
        var channel = pusher.subscribe('conversation.' + conversationId);

        $(document).ready(function() {
            $.ajax({
                url: '<?= BASE_URL ?>/actions/fetch_messages.php',
                type: 'GET',
                data: {
                    conversation_id: conversationId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        const messages = response.messages;
                        const currentUserId = '<?= $_SESSION['user_id'] ?>';

                        const messageHtml = messages.map((message) => {
                            const isSender = message.sender_id == currentUserId;
                            const messageClass = isSender ? 'message-sender' : 'message-receiver';
                            return `<div class="message ${messageClass}">
                                        <span class="message-sender-name">${message.name}:</span> ${message.message}
                                    </div>`;
                        }).join('');

                        $('#chat-box').html(messageHtml);
                        $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Failed to load messages: ' + error);
                }
            });
        });

        channel.bind('message.sent', function(data) {
            const currentUserId = '<?= $_SESSION['user_id'] ?>';
            const isSender = data.sender_id == currentUserId;

            const messageClass = isSender ? 'message-sender' : 'message-receiver';

            var messageHtml = `
                <div class="message ${messageClass} my-2 p-2 rounded">
                    <span class="fw-bold">${data.sender_name}:</span> ${data.message}
                </div>
            `;

            $('#chat-box').append(messageHtml);

            $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
        });


        $('#send-message-btn').click(function() {
            var messageText = $('#message-input').val();
            if (messageText.trim() !== '') {
                $.ajax({
                    url: '<?= BASE_URL ?>/actions/send_message.php',
                    type: 'POST',
                    data: {
                        conversation_id: conversationId,
                        sender_id: '<?= $_SESSION['user_id'] ?>',
                        message: messageText
                    },
                    success: function(response) {
                        $('#message-input').val('');
                    },
                    error: function(xhr, status, error) {
                        console.error('Message send failed: ' + error);
                    }
                });
            }
        });

        $('#message-input').keypress(function(e) {
            if (e.which === 13) {
                $('#send-message-btn').click();
            }
        });
    </script>

    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>